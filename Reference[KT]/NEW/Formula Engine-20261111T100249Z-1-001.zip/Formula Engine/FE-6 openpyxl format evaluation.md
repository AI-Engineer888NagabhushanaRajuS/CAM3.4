# FE-6 openpyxl format evaluation

Status: evaluated as a writer/formatter, not a calculation engine. openpyxl 3.1.5 is installed in the tested environment.

## Demonstrated

The synthetic workbook format_demo/openpyxl_format_demo.xlsx demonstrates explicit column widths, row heights, merged headings, fonts/fills, a styled Excel table, wrap/alignment, number formats, freeze panes, filters, print titles, page area, fit-to-page, footer and conditional formatting. Formulas remain in the original XLSX. The stored price 4.9347 is not reduced to 4.93 before multiplication; display is two decimals. Values are labelled synthetic and are not a client cost report.

The workbook was converted to a one-page PDF with LibreOffice, not Excel. Visual inspection found a narrow price/status gap; explicit indentation was added and the PDF regenerated. The durable image is format_demo/openpyxl_format_demo_preview.png inside formula_engine_src.zip (Drive ID 1uJy7j3DVLaqy4Zo8hRHW7GdFowGWpEAP); the paired XLSX and one-page PDF are in the same format_demo directory. Final pixels were inspected after regeneration. Viewer differences remain possible in Excel.

## Recommendation

Use openpyxl to apply an agreed CAM house style after calculation. Keep raw numeric precision separate from displayed decimals, retain original formulas and write a clear calculation-status note. Use tables, validation, protection, panes and print layout to improve readability without rewriting business rules. Compare Excel/native previews before rollout.

## Limits and next checks

openpyxl does not calculate formulas or populate result caches. Excel may show old/blank results until a real calculation engine runs. LibreOffice preview values are a secondary oracle and must not be called Excel results. Pivot/charts, macros, unsupported extensions, external links and complex existing template features require explicit preservation tests. This demonstration does not prove round-trip fidelity for every client workbook.

No production output was changed. A format prototype is not client acceptance of a new template.
