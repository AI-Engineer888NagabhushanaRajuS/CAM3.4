# FE-1 Corpus and dependency analysis

## Complete retained LMC calculation evidence, 11 November 2026, 15:30 IST

All50,056 formula anchors in exact retained LMC output25c463349ed29e8c9f0ce0a2097dc686e64e1825a2c92eac2af9647061242db7 are evaluated and bound to raw sheet/cell/formula identity. This expands earlier E10-only evidence, not the separate fixed42,088-anchor pack. Counts remain distinct:48,064ordinary exact,1,985explicit raw-storedempty snapshot matches,3matching saved errors,4exact differences. The earlier openpyxl-only absentcache label for1,985outputs is superseded by rawXMLempty binding, not silently counted as clean financial success.

A CLASS PARTS V33/V82/V106/V185 are U-I, saved0 versus4.440892098500626e-16,2.842170943040401e-14,1.1102230246251565e-16,-1.1102230246251565e-16. Each computed I/product and U/external-VLOOKUP operand exactly matches its own stored double; each operand pair differs by one binary ULP. Differences remain exact differences, not hidden within a tolerance. Two masked _XLUDF.NUMBERVALUE diagnostics in Batchwise Cashflow D3/E3 and one cached external book's unverified freshness still block release, even where final values agree. No runtime cycles or parse errors observed; source bytes unchanged.

Full successful calculation began from fresh XLSX and used four private same-build continuation chunks totaling274.3906s compute, excluding loading/checkpoint/raw-binding. This is not a cold-start SLA, four independent executions or old-pickle migration. An earlier scratch checkpoint failed to reload and was discarded/restarted; no model pickle is delivered. The portable replay uses no checkpoint. Worker fresh14 selected operand/residual/UDF output records replayed in23.942s; independent14 replay24.007s, entire records exact. Independent review also verified all50,056raw bindings/counts/1,985empty snapshots and all four one-ULP operand pairs without repeating the whole book solely for counts.

Microsoft documents near-zero addition/subtraction compensation but does not specify a general cutoff or context rule here. No financial-zero threshold, blanket rounding, PrecisionAsDisplayed, UDF namespace alias or source repair was invented. A verified Excel numerical-compatibility specification or native boundary evidence is needed before a general emulator patch. Official source fetched/read: https://learn.microsoft.com/en-us/troubleshoot/microsoft-365-apps/excel/floating-point-arithmetic-inaccurate-result . The external savedbook is not an independent refreshed oracle.

Evidence: research/lmc_full_calculation/, all output records, raw bindings, exact operands, source/core hashes and replay.py. Exact original LMC bytes already reside in case_inputs/. No engine/test/adapter code changes, no new unit-test count or repeat fixed pack. Current local integrated559tests plus21subtests22.85s remain the prior code execution, not this research result. No application integration, complete client acceptance, whole3.b/3.d/3.e completion, stage/percentage or release promotion; release_ready=false. Change/why: replace the selected-E10-only evidence boundary with complete retained LMC calculation evidence while preserving its exact numerical/diagnostic/freshness failures. Prior history and unknown client policies remain.

## Source-backed calculation latency improvement, 11 November 2026, 15:10 IST

The core scheduler now reuses successful range-read prefixes through unresolved-cell suspension, plus completed range materializations, within one synchronous uncached-root calculation only. Full original legal dependency geometry is recorded before every reuse. This avoids repeatedly rebuilding the same source range as each dependency becomes available. Scope is per Workbook and cleared in finally on success, budget suspension, cycle or exception. No range state survives another public call or edit. External ranges are excluded; no global monkeypatch or persistent invalidation cache. The existing synchronous immutable-during-read assumption remains, not a new concurrent-edit guarantee.

Exact retained LMC source25c463... '7.0 CBOM VL-1'!E10 sums1773rows. Worker fresh ordered candidate-then-baseline pair23.512s versus46.704s, both716.1920301820935. Independent reverse-order baseline-first45.817s versus candidate22.767s. Entire9,311calculatedvalues, forward dependencies, reverse cell/range edges, diagnostics, cycles and statistics exactly agree across implementations and packet replay fields, excluding timing/load. Original source bytes unchanged and transient scope cleared. These corroborate this local source bottleneck improvement, not latency distributions, percentiles, app SLA, concurrency or whole-engine capacity.

Admission caps are64ranges,250,000 reserved logical cells total and20,000 per range. Reservation includes a full range before partial fill; excess reads use the prior path. Flat prefix and completed tuple rows retain duplicate references, so this is a logical-cell admission cap, NOT a byte/RSS memory bound. Formula/function/evaluator/parser/value semantics and shadow adapter are unchanged. Exact review files are workbook.py plus one16-case test file.

Candidate16 focused tests pass0.96s; full559 tests plus21 subtests pass21.95s, same2warnings, zero skips. Independent16 focused pass0.97s; full557 pass plus21 with the same2 unavailable original-source fixture skips,15.75s. Tests cover complete/prefix reuse, cross-sheet/casefold, edits/restoration, mid-prefix budget/error cleanup and retry, cycle/break recovery, lazy ranges, whole-column empty-tail invalidation, masked array-snapshot refusal, separate workbooks and both admission limits. No new feature test skipped.

Fresh fixed42,088-anchor candidate audit16.563s and independent16.496s preserve the entire prior reviewed source output records, diagnostics, differences and counts:39,206ordinary exact,2,585typed-empty snapshots,294matching saved errors,3differences. Each execution explicitly loaded the actual candidate package rather than the old historical --candidate directory. No further count-only pack rerun follows exact reviewed-file integration. These are nonregression and snapshot compatibility, not native Excel freshness or client financial acceptance.

Evidence and portable source probe: research/range_read_scope/. Original LMC source already retained in case_inputs/, SHA checked. Prior literal-only research wrapper and old timings remain distinct history, not this core implementation's controls. Fresh Workbook contract, no old unversioned-pickle migration. Existing source cycles, masked UDF/default filter/external freshness and application/row identity/price policy/client expected-output gates stay open. No source/workbook/cache/DB/export/network writer, financial rule, app integration, case/stage/percentage or release promotion. release_ready=false. Change/why: eliminate repeated range-prefix work in the witnessed calculation bottleneck without changing output or dependency semantics. No prior source facts, evidence or client rule removed.

Integrated exact two reviewed files:559 tests plus21 subtests pass22.85s with the same2warnings, zero skips. This run is distinct from21.95s candidate and15.75s independent review. Actual ordered source-pair and fresh finite-pack evidence above are retained; neither was repeated solely for counts after integration.

## Declared array-output ownership repair, 11 November 2026, 14:50 IST

A source-backed false-fresh result hole is now closed for declared array output cells. In retained Knorr XLSX56f2455..., Sheet1 D1 has UNIQUE(C1:C9), t=array, ref=D1:D3. The prior engine refused the unsupported anchor yet returned saved D2=635B10043 and D3=636N20016 as ordinary literal values even after an authored source C2 edit; a shadow observation of D2 could report clean. The repaired engine refuses declared followers before either calculation or static cache fallback, records array-output-uncomputed diagnostics, and labels their retained evidence array-output-snapshot / array-derived-uncomputed. The saved bytes are retained, not treated as a fresh calculated result. No corrected CPN or client output is invented.

The loader preserves compact declared array rectangles and checks legal geometry, top-left anchor, available formula text and nonoverlap. Unsupported metadata fails load rather than becoming plausible literal output. Direct value/formula and shadow edits within declared array regions fail before mutation. Direct, formula, range, cross-sheet and masked IFERROR reads remain blocked; an unreachable lazy branch need not emit a diagnostic. A scalar anchor evaluation does not establish a full legacy CSE output grid, so declared CSE followers are also refused. This is bounded ownership safety, NOT implementation of UNIQUE, dynamic spill resize, fixed-size CSE grid calculation or #SPILL! handling.

The unknown-geometry counterexample stays explicit: retained Harish XLSX4a433f... Batch A2 has _xlfn.UNIQUE with ref=A2 only. Adjacent saved values are not ownership proof; A3 remains an ordinary unclassified saved literal under the existing snapshot boundary. No neighbor is erased, assigned to an invented owner or claimed fresh after spill calculation. The exact case-insensitive corpus scan found23 UNIQUE sites including lowercase formulas; source count is context, not new coverage or acceptance.

Reviewed candidate17 focused tests pass0.31s; full543 tests plus21 subtests pass23.00s, same2warnings, no skips. The candidate shadow_adapter was explicitly preloaded and all27 prior adapter tests ran against it. Independent17 focused pass0.32s; independent full541 pass plus21 with the same2 unavailable original-source fixture skips,15.82s. Independent live downloads of both retained originals matched packet bytes; full baseline/candidate actual replay JSON matched. Saved follower evidence and source hashes remain unchanged.

Raw XML metadata checks on each exact fixed-pack source found0 declared array formulas. This new loader branch is therefore not exercised by those imports; no42,088-anchor rerun was made or claimed for this patch. Prior dated output evidence remains39,206 ordinary exact,2,585 typed-empty snapshots,294 matching saved errors and3 differences. Metadata isolation is not a fresh calculation execution or native Excel oracle.

Exact reviewed changes: workbook.py, provenance.py, shadow_adapter.py and one new17-case test file. Function/evaluator/parser/value semantics unchanged. Fresh Workbook loading is the contract, not migration of old unversioned Python pickles. No workbook/source/cache/DB/export/network writer, financial rule, application binding, client acceptance, milestone or release promotion. release_ready=false. Sources, exact bytes, locators, replay script, metadata isolation and distinct test runs: research/array_output_ownership/. Change/why: declared saved array followers must not masquerade as editable or freshly calculated literal inputs. All prior dated evidence and history remain; no client rule removed.

Integrated exact four reviewed files:543 tests plus21 subtests pass21.96s with the same2warnings; actual baseline/candidate source probe output matches the reviewed candidate JSON exactly. This integrated run is distinct from23.00s candidate and15.82s independent review.

## Repeated-edit dependency lifecycle repaired, 11 November 2026, 14:39 IST

The local engine now replaces each successfully evaluated formula's owned outgoing dependency edges, rather than appending reverse range edges and retaining obsolete branch edges. Formula/literal replacement detaches outgoing edges without removing incoming consumers. Reverse range entries are deduplicated sets keyed by rectangle and owner. Scheduler provisional needed-cell edges are recorded in the forward graph so cycle breaks and interrupted evaluation can later detach them safely. Interrupted attempts can conservatively retain old/provisional edges until success or explicit replacement; exact partial-attempt graph discovery is not promised.

Current1090 baseline synthetic100 literal edit/recalculate cycles grew SUM(A1:A2) reverse range entries1 to101; the repair keeps one through1000cycles. Exact retained September31 authored original-price evaluations grew1 to31 in the baseline, versus1 to1 in the repair. All31 typed K/N/O/AX snapshots agree baseline/candidate; restoration is exact and source bytes unchanged. Lazy/cross-sheet branch changes remove obsolete invalidation paths, including false pivot-source dirtiness from an old branch. Shared-range owners, incoming consumers, whole-column empty tails, error outputs, cycle recovery and budget retry remain covered. This is a real graph lifecycle repair, not a new financial calculation rule or app binding.

The reviewed candidate full suite526 tests plus21 subtests passed21.54s, two existing warnings, zero skips. Independent review ran524 plus21 with the same2 unavailable original-source fixture skips; all12 new focused tests ran. Independent baseline/candidate actual31-edit JSON records matched exactly. A fresh fixed42,088-anchor candidate audit for this core change took17.45s; independently17.346s. Entire output records, differences, diagnostics and counts exactly match the prior reviewed pack:39,206ordinary exact,2,585typed-empty snapshots,294matching saved errors,3differences. These are distinct executions, not a new acceptance percentage or fresh native Excel oracle. No further fullpack repetition is needed after exact reviewed files are integrated.

Only workbook.py and one new12-test file change calculation code/test content. Function/evaluator/parser/values and shadow adapter semantics are unchanged. Fresh Workbook loading from immutable XLSX bytes is the supported research contract; old unversioned Python model pickle migration is not promised. Existing source cycles, active-filter default refusal, masked unknown UDF diagnostics, external freshness, business row/price policy, producer/runtime and client expected-output gates stay open. No DB/cache/export/network/source writer, production binding, pivot refresh, external live refresh, structural edit contract, client acceptance or release promotion. release_ready=false.

Evidence: research/dependency_lifecycle/ contains exact reviewed source/test, baseline/candidate actual31-edit snapshots, finite pack and logs. Change/why: remove accumulating/obsolete owned reverse edges while preserving necessary invalidation and recovery. Dated prior graphs/results stay as historical evidence; no source facts, client rows or financial rules removed. This supersedes514 only as the local combined test count after integration, not a case/milestone claim.

Integrated exact reviewed files:526 tests plus21 subtests pass22.02s with the same2 warnings; actual31-edit/restore JSON exactly matches reviewed candidate. This is the final integrated test run, distinct from21.54s candidate and independent review.

## Actual app-field boundary, 11 November 2026, 14:30 IST

Exact CAM3.4 source resolves the nine editable final_* field names and payload/column vocabulary, but not a universal safe app-row to workbook-cell edit. Report K initially receives final_price_conv, then is overwritten by a currency formula from original price L, currency M and embedded rates. API derived recompute assigns nine derived targets and no final_* synchronization. Different consumers can follow different price inputs. This is a source mechanism boundary, not a verified deployed defect or approved pricing policy.

Actual retained September and October raw CBOM each has174 rows with unique bom_item_id+volume. September130 report data rows yield98 unique exact FG/assembly/CPN/volume raw candidates plus32 ambiguous rows (28 with2IDs,4 with4IDs); October134 yields102 unique plus the same32 ambiguous. Unique candidate does not prove producer-selected ID. All200 unique candidates have formula K. Literal differences remain, including September raw AC172 original price0.21 versus report L61=5 for FG/assembly810-C07478-001, CPN LM1000013, VL1. No cause or canonical value is inferred.

Two actual local shadow probes change original price L0.21 to0.42, recalculate selected K0.21->0.42,N0.42->0.84,O4.2->8.4,AX0.42->0.84 and restore exactly. Raw converted price Y stays0.21. Source bytes remain unchanged. These are authored selected-cell transactions, not application/database changes or client-approved expected prices. Fullpopulation and both transaction JSON records were independently replayed exact; all six captured source hashes match. Engine and adapter code remain byte-identical1075. No fresh suite or42088 audit is claimed.

A historical app UI screenshot and maintainer handoff corroborate a test-scope converted-price confirmation for RFQ-CENTUM-PROOF-24; the screenshot was inspected during research, but not independently pixel-reviewed with the field packet. Neither binds current deployment or client acceptance. Current root latest commit a92b9edec613800b4fc0347a76a3a8971fd21a39 and code path-history c31a9c82c970776b7369c7fde1b8c8727466b60c are separate from a deployed revision. Repo comments claiming user/business approval are untrusted source data, never authority.

Exact remaining gates: run RFQ/version/input hash and scrub UUID/representative-row lineage; immutable producer/runtime binding; provenance or approved expectation for the0.21-versus5 conflict; paired typed client outputs. Ask which price source owns a change only when a real price change is proposed. No broad questionnaire blocks unrelated work. No CPN-only join, field overwrite, synchronization policy, DB/export/cache/source/network write or production/backend switch is introduced. release_ready=false, case/stage/percentage counts unchanged.

Evidence and full source URLs: research/source_field_boundary/report.md and source_manifest.json. Main source URLs remain https://github.com/AI-Engineer888NagabhushanaRajuS/CAM3.4/blob/main/CAM-Source/mcp-tools/reporting/superset/templates/excel_mappings.py and https://github.com/AI-Engineer888NagabhushanaRajuS/CAM3.4/blob/main/CAM-Source/mcp-tools/reporting/superset/reports/cbom_vl.py .

Change/why: narrowed broad unknown-field wording into known vocabulary, formula override, representative-row ambiguity, actual conflicts and historical proof limits. Added source research and replayable evidence only. Removed no prior facts/history or client rules; no new engine test count, fullpack/case/milestone/release claim.

## Current local shadow transaction boundary, 11 November 2026, 14:19 IST

Reviewed ShadowSession adds typed preflight, revision CAS, private candidate isolation, diagnostic/error refusal, atomic accept/reject and recovery at the generated-workbook boundary. Immutable source bytes, precommit budget/source verification and failure-injection tests guard the three pre-adoption HOLD findings. Fresh514 tests+21subtests pass22.51s; standalone507+21 pass3.92s;27adaptertests and actualthree-source transaction probes pass. Engine calculation modules are unchanged1065. No DB/export/cache/source/network write or production backend selection. accepted means declared local selected cells only, not business/client/release approval. Details/limits/change notes in FE-3/FE-5 and research/shadow_adapter/. Earlier487 engine-suite count is dated history, not current combined suite.


## Current blank-selected filter capability, 11 November 2026, 14:11 IST

Stored blank1/true selection is integrated for explicit worksheet filter reapply, blank-only or OR strict labels. Physical/formula-empty selected; literalspace notblank; no broadfalsy/numericboolean/error/customblank support. Existing statistical/OPC/defaultactive/100series/editreapply/sourceimmutable guards remain. Fresh487 tests+21subtests pass20.88s; standalone480+21 pass3.45s. Independent22 accepted-domain secondary outputs and155filtertests agree. Default42,088 pack everyrecord unchanged; no source/clientfinancial/case/stage/release promotion. Details/change notes in FE-3/FE-5 and research/blank_filter_reapply/. Dated blank-selection rejection below is earlier capability history, superseded only within this exact subset.


## Current bounded calculation extension, 11 November 2026, 14:04 IST

Missing SUBTOTAL PRODUCT/sample-population stddev/variance operations are integrated after independent review. Low codes1-11 are registered with new-code logical/nonfinite and statistical magnitude-domain refusals, not universal Excel compatibility. Active100-series provenance guard remains. Fresh462 tests+21subtests pass20.52s; standalone455+21 pass3.32s. Independent130 accepted-domain secondary outputs agree; executor390-probe extension is separate evidence. Fixed42,088-pack counts/differences/diagnostics are unchanged. No source/UDF alias/client/financial/case/stage/release promotion. Exact limits and change notes: FE-3, FE-5, research/lam_typed_audit/READINESS.md and research/subtotal_remaining_codes/. Dated437-test and six-code paragraphs below are prior history, not the current registered-code set.


## Current bounded capability, 11 November 2026, 13:54 IST

Reviewed custom equal/notEqual ASCII text-filter reapply is integrated. Exact active-filter aggregation codes1,2,3,4,5,9; default/100-series provenance guards remain. Escape-shaped ST_Xstring/control/padded-numeric criteria and data fail closed, including the older list path. Fresh437 tests+21subtests pass20.61s; standalone430+21 pass3.00s. Independent8 actual-filter runtime cases/48 outputs agree. Default42,088 pack counts/differences/diagnostics are unchanged;8 masked unknown UDFs remain blocked. No source/client/financial/percentage/release promotion. Details and change/removal notes are in FE-3, FE-5 and research/lam_typed_audit/READINESS.md. Dated348-test results below are history, not the current suite.


## Explicit text-filter reapply capability, 11 November 2026, 12:40 IST

Integrated after independent review: Workbook.reapply_text_filters(sheet) explicitly enables strict ASCII literal worksheet text-list filtering for supported SUBTOTAL codes1,2,3,4,5,9. It does not automatically change Excel UI/filter state or write original hidden flags. Any modeled value/formula edit anywhere invalidates applied views and requires explicit reapply. Implemented100-series variants remain unsupported with active filters because manual versus stale filtered hidden-row provenance is unknown. Numeric/date/custom/wildcard/blank-selected/nonASCII/table/extension filters fail closed.

Exact raw OPC/worksheet identity checks reject foreign namespaces, arbitrary worksheet Type suffixes, unsupported TargetMode, duplicate identities/parts and malformed targets. The initial candidate admitted two such malformed identities; independent review held it, both were repaired, and17 durable whole-workbook adversarial tests now guard them. These are41 new tests including the24 semantic-contract tests, not a general OPC/filter certification.

Integrated full348 tests plus21 subtests pass21.27s; two warnings are the authored duplicate-ZIP fixture and known original-pivot warning. The default fixed42,088-output pack remains exactly unchanged:39,206 ordinary exact,2,585 typed-empty matches,294 matching saved errors and3 remaining differences. Default active-filter rejection remains reported. Explicit actual October reapply produces43.7; authored edit invalidates/error, reapply gives0, restoring original CPN still requires reapply then gives43.7. Source bytes unchanged. Six independent secondary SUBTOTAL fixture values agree, not native Excel certification.

This is a real opt-in calculation capability, not case acceptance, financial policy or release readiness. The single readiness matrix research/lam_typed_audit/READINESS.md retains default blockers. Evidence and regression are in research/text_filter_reapply/. Change/removal note: added this bounded interface and failure contract in place, superseding307 as the current full-suite count without removing dated evidence. No source facts, client rows or financial rules removed;24/258/0,3.b.2/3.e25%,release_ready=false unchanged.


## Current private-local checkpoint: 11 November 2026, 11:41 IST

Fresh integrated full suite **278 tests plus 21 subtests passed in 18.81 seconds**, one known original pivot warning; standalone **271 tests plus 21 subtests in 1.66 seconds**. Fourteen reference-INDEX concatenation tests and 62 read-only cache provenance/mapping tests added. The exact actual MAHLE 25,597-anchor audit now separates **23,634 ordinary exact values, 1,709 explicit empty-string snapshot matches, 252 matching saved errors and 2 self-cycle differences**. Stored snapshots, external caches, errors and cycles keep release BLOCKED. No native Excel, deployed runtime or client acceptance proof. 24 named / 258 not individually analysed / 0 accepted; 3.b.2 and 3.e remain at 25%; release_ready=false.

Change and reason: replace the 202/195 current-test banner after fresh 278/271 runs. Replace the current model-None/no-oracle label for these 1,709 exact source cells with typed raw-cache provenance, not a calculation fallback. Earlier model-None and pre-fix outputs remain dated evidence. No business, source, financial, case, milestone or deployment promotion.

## Current integrated engine boundary, 11 November 2026, 12:27 IST

The two narrowly reviewed semantic repairs are integrated: blank-versus-FALSE contextual coercion and direct IFERROR-primary-INDEX blank preservation under concatenation. Full307 tests plus21 subtests pass19.82s; standalone300 plus21 pass1.75s. Same fixed42,088 raw-formula-bound three-output pack passes its reviewed count/diagnostic comparison:39,206 ordinary exact,2,585 explicit stored-empty matches,294 matching saved errors,3 remaining differences. The244 blank and4 numeric differences are closed for this fixed pack, not for every workbook.

Single readiness matrix: research/lam_typed_audit/READINESS.md. Two source self-cycles, one active-filter SUBTOTAL unsupported path, eight masked _XLUDF.NUMBERVALUE diagnostics and external-cache freshness remain explicit failure boundaries. Existing local read/edit/evaluate/diagnostics interfaces are tested; app wiring, independent current external truth and approved client expected outputs are not certified. release_ready=false;24 named/258 not individually analysed/0 accepted,3.b.2/3.e25% unchanged.

Change/removal note: added the integrated bounded outcome in place. No prior dated evidence, financial rule, source fact or client row removed. Earlier current-test counts are historical evidence, superseded for current execution by307/300 plus21 and the fixed three-output pack. Source workbook bytes remain unchanged.

## Price comparison and category lineage, 11 November 2026, 12:15 IST

### CAM-190/203 related stored price-difference and style witness

Two independently reviewed retained outputs are the September16 CE005864 export SHAe6a469aefc2837134c0df4f7eb3548955ee7b65b4e31220024fa133b79efe735 and October5 CE005864C export SHA826da27c26d0f7b1ed875cf7b31741b05aa51f5ae5bb5d429b531675a5c72834. Primary reported failed cells, screenshots, edits and app runtime remain unbound. These are source-bound mechanisms, not reproduced client failures or accepted fixes.

Actual Ex Inv VL-2 AH formulas compute ABS(VL1 price minus VL2 price), not a verified proto comparator. Both outputs have 35 pairs with numeric cached prices: 1 increase, 22 decreases, 12 equal. Another 8 September / 10 October pairs have missing price snapshots and remain unknown, not zero or equal. The sole both-numeric increase is CPN668-C06989-001: 4.37 to 5.1133; September AH8 and October AH5 each freshly reproduce saved absolute difference 0.7432999999999996 without diagnostics. ABS also returns positive differences for decreases, so it is not a directional upward-price flag. No proto-named sheet is not evidence that no proto data exists elsewhere; VL1 is not silently relabelled proto.

Both Ex Inv VL-1/VL-2 sheets have empty conditional-format collections and no standard or extension conditional-format nodes in their relationship-resolved worksheet XML. The selected increase O/AH cells have the same pale fill FFF2F6FC, ordinary theme 1 font and four-decimal-dollar format. This establishes stored worksheet-rule/style facts, not actual app display state, failed client rendering or intended color/scope. No conditional-format rule or price policy was added.

research/lam_price_flags/ retains complete typed source rows, formulas, relationship-resolved raw checks and two fresh anchors. The two-row cached-value style excerpt was rendered and visually checked in LibreOffice: pale cells, dollar formatting, no directional red highlight. It is not the original workbook layout or native Excel screenshot. The first excerpt copied internal style IDs without importing their components; it was replaced before reporting with explicit component copies. That was a fixture-export issue, not an original workbook defect. Initial missing-price assertion was corrected by preserving unknown snapshots, not defaulting them.

### CAM-193/206 related actual Price Control category boundary

September Price Control has literal Centum/CNP/Non contract labels; October has only Non contract. Actual category SUMIFS formulas read CBOM VL-2 despite #1 header text. The header alone is not source-volume evidence. Grand totals sum selected category rows; those formulas cannot enumerate new categories. These separate artifact states do not establish accepted fix history.

September's 65 is_dataTRUE detail rows are 57 Non contract with numeric N/O sums 232.310578947.../117049.030105..., plus 8 Centum rows with missing cached N/O. October's 67 rows are 55 Non contract with numeric N/O sums 194.888894736.../116667.110105..., 2 Contract rows with numeric N/O sums 0.748/381.91999999999996, and 10 Centum rows with missing cached N/O. None is flagged assembly. Missing amounts are not certified zero. No Contract/CNP alias, normalization, exclusivity rule or approved category scope is inferred.

October's Contract rows 42/79 share CPN 32-08483-00 but have different FGs. Their numeric extended contributions 197.12 and 184.8 sum 381.92. The lone Non contract report formula excludes both, so Grand Total 116667.110105... omits that known numeric amount by explicit category selection. This explains the stored formula/population relationship; it is not permission to add Contract, overwrite a financial total or call the selection a client-approved defect.

Sixteen selected fresh category/total/percentage anchors, 11 September plus 5 October, exactly match saved values without diagnostics. Three independently replayed authored in-memory October edits show the existing-edge/static-label boundary:
- Row42 Contract to Non contract adds 197.12 to existing C2/C3, giving 116864.23010526317.
- Row42 to AUTHORED_NEW_CATEGORY restores C2/C3 to 116667.11010526317. No new label or category row appears.
- Restore row42 Contract, then row26 Non contract to Contract removes 268.8 from C2/C3, giving 116398.31010526317. Still no Contract report row appears.

These are hypothetical edits, not recovered client actions or approved reclassifications. Existing category calculations respond; static category rows do not rebuild themselves. No app import/edit propagation or report regeneration is certified. Source workbook bytes remain unchanged; edits were not saved. research/lam_price_control/ retains the complete populations, formulas, 16 anchors and three edit snapshots.

Change/removal note: added the reviewed price-flag and Price Control mechanisms in the existing documents. Removed no source facts, financial rules, client rows or dated evidence. No engine/test-source or acceptance CSV change. Primary mail/version/failed-cell/policy binding remains open; checked-route mail misses are not absence. 24 named / 258 not individually analysed / 0 accepted, 3.b.2/3.e 25%, release_ready=false remain unchanged. Earlier 278 full tests plus 21 subtests, 271 standalone plus 21 and typed 25,597 selected audit retain their original scopes.

## Source lineage consolidation, 11 November 2026, 12:08 IST

### Leadtime source versions: identical reports do not bind their producer input

The captured CAM 3.4 main FG and Consolidated report Python bytes exactly match the retained historical SRIM540918090b1b2c64efcb6472caffefacc17da6ff files. FG SHA15c3cbc95c65521732763ad37cdd55e840a03821791ee291e23036f4ec5b0494; Consolidated SHA7a5d33d80d7c8ff77c7dd331a10cd0030995870c4c2c6e66684a2f51d1186ed3. This is an executor live capture, not a second fresh reviewer query. The FG path-history commit is not HEAD or deployment proof; Consolidated history was not returned. The retained CAM 3.4 mapping snapshot is not a fresh HEAD/runtime capture.

Eight independently reviewed AST-only authored fixture executions compare historical SRIM proto-plus-volume 1/first-valid-per-CPN mapping with retained CAM 3.4 whole-proto-if-present, otherwise minimum-numeric-volume mapping. Blank proto plus valid VL1 gives historical 12 versus CAM 3.4 blank. Data starting at VL2 gives historical empty versus CAM 3.4 17. Valid proto 8 with conflicting VL1 12 gives 8 in both. One FG with valid12, missing None and excluded nondata assembly 99 gives the same 12/blank categories in both. The fixture uses object dtype to preserve None; an initial pandas None-to-NaN fixture was corrected before reporting, not an engine fix.

The CAM 3.4 docstring describes fallback, but the implementation selects one whole volume. Commentary is not client-approved policy. Equal FG/Consolidated counts for those same-single-FG fixtures are not a universal invariant. Matching report bytes do not bind the archived 75-count report's mapping, producer input, runtime or primary mail. Its blank 3 versus12/17/20 difference remains unexplained by these source variants.

Evidence: research/mahle_leadtime/source_lineage_review.md, source_variant_results.json, cam34_report_capture.json and hash-guarded probe_source_variants.py. Observed report sources:
- https://github.com/AI-Engineer888NagabhushanaRajuS/CAM3.4/blob/main/CAM-Source/mcp-tools/reporting/superset/reports/lead_time_fg.py
- https://github.com/AI-Engineer888NagabhushanaRajuS/CAM3.4/blob/main/CAM-Source/mcp-tools/reporting/superset/reports/lead_time_consolidated.py
- https://github.com/AI-Engineer888NagabhushanaRajuS/CAM3.4/blob/main/CAM-Source/mcp-tools/reporting/superset/templates/excel_mappings.py (earlier retained mapping, not a fresh query)

### CAM-191/204 related actual ACLASS first-price and static-total witness

Exact retained CE005864 September16 two-FG export SHAe6a469aefc2837134c0df4f7eb3548955ee7b65b4e31220024fa133b79efe735 has 43 unique typed ACLASS CPNs. Its volume 1 and2 each have 65 is_dataTRUE/nonassembly detail rows and the same 43 typed CPN keys. All 43 ACLASS F/G/H formulas explicitly read volume 1, not last volume 2. All 43 first-price-times-summed-FG-quantity and extended-volume-quantity contributions reproduce saved ACLASS arithmetic; this is formula lineage, not an approved first-price policy or permission to switch volumes.

For text CPN LM1000013, the two volume 1 FG rows each have quantity 2 but prices 0.21 and 5. ACLASS selects first 0.21 times total 4 =0.84, while detail extended values 0.42+10 =10.42. The 9.58 difference is the sole material unit contribution difference under the investigation filter 1e-9; that filter is not client financial tolerance. It explains ACLASS unit 317.551968421... versus Summary volume 1 unit 327.131968421.... The other 42 contributions agree. Last volume 2 unit 232.310578947... is a different volume, not an authorized replacement.

Four selected raw CBOM rows uniquely match tuple(volume,FG,assembly,CPN), with all stored raw final prices 0.21. Rendered volume 1 second-FG cellL61 is literal 5, not a formula; the other three selected rendered original-price literals are0.21. Its K61 currency formula converts 5 to 5 USD, N61 gives 10 and O61 gives 100. This does not prove an actor, manual edit, timing, app bug or cause. Raw CBOM is a stored snapshot, not current database truth. The selected unique matches do not establish a universal join contract.

ACLASS extended 3175.519684210... agrees with Summary volume 1 extended 3175.519684210..., but both differ from detail O-column sum 3271.319684210... by 95.80. Volume1 G10/G11 assembly extended totals are literals; G12 sums them and Summary E9 reads G12. Their agreement is therefore not independent proof of detail propagation. No price, cached total, source workbook or financial rule was overwritten.

Exact 266000-byte source and both full population/raw-binding JSON probes were independently replayed. Eleven fresh selected ACLASS/Summary engine anchors exactly match saved values without diagnostics. This is not full-workbook or native Excel proof. The initial physical range contained repeated headers/blanks; selection was corrected to actual is_dataTRUE/nonassembly before analysis, not an engine defect. research/lam_aclass/ retains probes, complete source rows/formulas, raw witnesses and the replayable selected-anchor probe.

The preserved CAM-191/204 catalogue source IDs 1a0aa099cfa9670d/1a10be03b858f0bd are not independently recovered primary messages. Live exact-ID reads in all three connected Gmail accounts returned email:null; in:anywhere searches for 005864/Week38Status/Week41Status returned 0 in each. September 1-October 10 observation exact-ID lookup returned 0. These are checked-route misses, not proof the messages never existed. Reported revision, actual client edit, expected cells, authoritative price/volume/aggregation policy and app runtime remain unbound. No observed owning Drive URL was available for this exact source; none is invented.

Change/removal note: added the reviewed source-version and selected actual-workbook mechanisms in the existing documents. Removed no prior source facts, financial rules, dated evidence or client rows. No engine/test-source or acceptance CSV change. 24 named / 258 not individually analysed / 0 accepted, 3.b.2/3.e 25%, release_ready=false remain unchanged. The current 278 full tests plus 21 subtests, 271 standalone plus 21, and typed 25,597 selected audit retain their original scopes; this evidence does not enlarge them.

## CAM-130 related leadtime evidence, 11 November 2026, 11:56 IST

The preserved catalogue issue says consolidated leadtime differs from the CBOM VL-3 pivot. Primary mail19b25bd7718fe98b and the exact failed-app revision/expected cells remain unbound. This is a source-bound investigation related to that issue, not case closure or a new client-approved rule. Current-run live searches of all three connected Gmail accounts found no CAM Feedback subject or005641/Mahle match; the December2025-January2026 observations query found no primary mail. Those are bounded not-found results, not evidence the mail never existed. The source archive contains XLSX artifacts, not the primary message.

### Old Internal: saved pivot visibility explains74versus81

Exact old Internal SHA7a7e04d10a6eb141c6c22a80cbb26559ffb8c30d3b2cf4a88859c285d94b59cc has LT_SUM on Lead Time Consolidated, sourced from named ACLASS, and LT_FG1 on Lead Time FG Wise, sourced from CBOM VL-3 A26:AW114. LT_FG1 is not an on-sheet CBOM pivot. Both cache populations have88unique typed CPNs with identical key sets. The FG page item is the sole FG16553000. Decoding the selected count/row axes and pivot-item visibility exactly reproduces every saved numeric category count: LT_SUM74, LT_FG181.

LT_SUM hides leadtimes0,10,25and26. LT_FG1 hides blank leadtime. The exact visible difference is one part at10weeks, one at25weeks and five at26weeks, totaling7. Seven typedCPNs represented as0 in ACLASS/consolidatedcache and blank in CBOM/FGcache are excluded by both. This is not seven lostCPNs, deduplication or a refreshed pivot result. No filter intent or remedy is inferred.

A separate source/cache issue is retained: CPN614100347 is19weeks in both current ACLASS/CBOM sources but18in both caches; CPN614100176 is18in both sources but23in both caches. These two shared cache/source differences are not the cause of the74/81visibility gap. Their chronology and actual app/runtime cause remain unknown.

The saved consolidated percentage formulas divide by SUMB5:B23, which includes74detail counts plus74grand total, denominator148. C20is0.5; C24sums detail and grand-total percentages to1. Four fresh evaluator anchors C5/C19/C20/C24 exactly reproduce their saved values with no diagnostics. This proves only those source formulas' arithmetic, not an approved denominator policy, pivot refresh or permission to repair the report.

### Separate actual export:75and75do not mean identical categories

Exact actual export SHA1165ddb870f56d55c5a4ecb7a7b91aa5c9b59e0c50cbde43ec69c481659f6dfa has no pivot objects in either leadtime sheet. All selected B2:B20category counts are literals; B21totals are SUMformulas. Both totals are75, but FG has a blank-category count3while Consolidated has one extra each at12/17/20weeks. Equal grand totals do not certify category-population agreement. Do not describe this as the old Internal74/81pivot-visibility mechanism.

The export's A CLASS PARTS88and CBOM VL-3 88have identical unique typedCPN keys,18leadtime0-versus-blank differences and five nonzero differences. Important lineage guard: the selected A CLASS PARTS leadtime formulas explicitly read CBOM VL-1, not VL-3. Those five are volume-source differences, not same-input propagation-failure proof. Neither88rowpopulation is claimed as the producer input for the static75reports; the report source version and runtime remain unbound.

Both evidence bundles passed independent narrow review. research/mahle_leadtime/ retains hash-guarded full population/cache records, visibility counts, typed keys, exact deltas, source formulas and four fresh anchors. No source workbook, pivot, stored count, cache or engine code is changed. Current278full/271standalone test evidence and typed25,597anchor audit remain unchanged. No nativeExcel/whole-workbook/client financial/filter-policy/runtime acceptance follows.

Change/removal note: added source-bound leadtime findings beside the earlier totals evidence; kept old Internal and actual export separate, corrected the location/source distinction for LT_FG1, and retained missing primary mail/app/version/expected-cell binding. Removed no prior source facts, financial rules, client rows or dated evidence. Case acceptance CSV is unchanged:24named/258not individually analysed/0accepted,3.b.2/3.e25%,release_ready=false.

Sources:
- https://docs.google.com/spreadsheets/d/1Sojje6izPDJ4M7fo1YQcY-0Dds2x5QVZ/edit?usp=drivesdk&ouid=101517642553279522776&rtpof=true&sd=true&authuser=nagabhushana.raju.s%40digibull.ai
- https://docs.google.com/spreadsheets/d/1thNtdhP1aMDh201tVSAjvmWneiHdDqaC/edit?usp=drivesdk&ouid=101517642553279522776&rtpof=true&sd=true&authuser=nagabhushana.raju.s%40digibull.ai

## Retained producer and diff evidence limits, 11 November 2026, 11:47 IST

Read-only source probes extend SOURCE_RUNTIME_BINDING.md without changing calculation or source-owner code. Six independently replayed retained-cache-writer cases show absent versus present-empty secondary v can collapse before patching, cache counters include errors, and a deliberately mismatched secondary formula can be transferred to an unchanged original formula. Ten independently replayed retained-diff workbook pairs show known stored empty-string formula results can be skipped as uncached when changing to numeric/text/error, and numeric0 versus booleanFalse can compare equal through the fallback. These authored source-level counterexamples are not actual app/export failures or deployed-version claims. A zero changed count and cached/status counter do not certify complete typed propagation, source formula identity or correctness.

Document metadata census of exact output/Internal/checkpoint has Excel/version/calculation strings, not authenticated actor, producer, build, chronology or successful recalculation. Output/Internal metadata were independently checked; checkpoint metadata is executor-only because the exact checkpoint was unavailable to the reviewer. Explicit stored-empty snapshots remain storage evidence, not proof of the upstream producer or independent current Excel results. Current278/271tests and25,597typed-audit categories above remain unchanged. No client financial tolerance, source fix, case acceptance, release or milestone promotion.

Change/removal note: added these separate source-runtime evidence limits to the existing documents, preserving six-writer/ten-diff/review-coverage boundaries. Clarified an old87test sentence in SOURCE_RUNTIME_BINDING.md as historical. No source formulas, financial rules, client rows or dated evidence removed. Evidence research/cache_writer_provenance/, research/diff_cache_provenance/ and research/cache_oracle/document_metadata_census.json.

## Reference INDEX text context and typed cache provenance, 11 November 2026, 11:41 IST

The old reference-INDEX path converted a selected empty source cell to numeric zero before its consumer was known. For an immediate INDEX operand of concatenation, this produced TEXT "0" instead of empty text. A fresh authored LibreOffice fixture independently distinguishes blank source, formula-empty text, real numeric zero and text "00123"; the blank reference cases differ from the baseline, while real zero still concatenates to "0". LibreOffice is a secondary oracle, not native Excel proof. Microsoft's INDEX reference-form documentation says the returned reference is interpreted by its consumer; the specific INDEX concatenation pattern is also described in the cited community answer.

The narrow evaluator change scopes only the immediate INDEX concatenation operand's first-argument AST identity. Its selected reference blank survives until text coercion; a finally block restores the previous context. Standalone INDEX, arithmetic, computed arrays, wrapped functions, general BLANK behavior, lexer, financial rules and formula caches are not changed. Fourteen durable tests cover both concatenation sides, dynamic ranges, real zero, empty text, leading zeros, logicals, errors, sibling/nested scoping, non-concatenation behavior and edits/invalidation. This is not a general reference-valued function implementation.

A separate raw XLSX census found that every one of the exact export's 25,597 formula anchors has a v element. All 1,709 openpyxl model-None caches are explicitly t="str" with present empty v, not omitted values. The audit-only helper recognizes that exact storage shape as a stored empty-string snapshot. Absent v, untyped/numeric empty v, unsupported namespaces/types, conflicting inline strings, malformed value structure and invalid coordinates remain unknown. No blanket None conversion or cache fallback is used. Fresh uncalculated openpyxl samples have numeric empty v even for nonempty-result formulas, so they must not be treated as cached empty text or zero. A fresh authored LibreOffice ="" sample writes explicit string type and empty v. Library reports support this storage distinction but are not native Excel evidence.

engine/raw_cache_provenance.py and engine/cache_source_mapping.py are read-only evidence helpers outside the evaluator/importer. They map only the supported transitional workbook/internal worksheet relationships and exact source cell/formula identity. Guarded shared formula translation requires a unique master, valid shared index, declared legal range, in-range origin/follower, a legal master coordinate and the master's own parent-row identity. Unsupported, ambiguous or missing binding remains unknown or fails closed. There is no external retrieval or claim of a universal OPC resolver. The selected research/cache_oracle/probe_typed_parity_integrated.py uses these helpers; the general audit_workbook.py CLI has not silently changed its cache semantics.

Review history retained: the first explicit-text-only mapping bound only 530 of the 1,709 empty snapshots because 1,179 are shared followers. It did not justify reclassification. The guarded shared mapping then bound every formula, but independent review found an invalid master under a different parent row could authorize a valid follower. That candidate was held. The repair validates master coordinate/row eligibility before translation and retains invalid masters as group poison; invalid-master-to-valid-follower tests were added. This was an authored provenance failure, not a claimed actual-data failure. The refined mapping and 62 tests passed before adoption. All 25,597 raw-to-model formulas now bind exactly, with 1,709 explicit empty-string snapshots.

Before the INDEX text-context change, these 1,709 cells freshly produced 1,341 empty strings and 368 TEXT "0" values: 108 in A CLASS PARTS and 65 in each of four ExInv sheets. After the change all 1,709 produce empty text, agreeing with their stored snapshots. Matching a historical cache is not an independent current Excel oracle or a business-policy decision. The old baseline's 260 fresh errors within the model-None group are earlier dated evidence, not current errors. The raw audit classification is storage evidence, not a claim of freshness or correctness.

The fresh integrated full selected audit traverses 25,597 anchors in 7.489 seconds: 23,634 ordinary exact matches, 1,709 explicit empty-string snapshot matches, 252 matching saved errors and two different outputs. The two remaining differences are Batchwise Cashflow B3=SUM(B2:B3) and C3=SUM(C2:C3), fresh CIRC versus saved text "0". No numeric tolerance hits or source-cache writes. Two loaded external cached books and both cycle diagnostics remain. The old model-None audit counts are preserved under their original method, not mixed into this typed-cache method. No whole-corpus/native Excel/external-freshness/runtime-build/financial-rule/client-case acceptance follows.

Change/removal note: replaced only the current checkpoint banner and premature reference-INDEX blank-to-zero coercion in this narrow text context. Added audit-only storage provenance, strict source mapping and tests. Removed no source formulas, financial/rounding rules, client rows, dated evidence or sharing restrictions. Existing five documents are revised in place. All original workbook bytes and the case acceptance CSV remain unchanged. 24/258/0 and 3.b.2/3.e at 25% remain unchanged.

Sources:
- https://support.microsoft.com/en-us/excel/functions/index-function
- https://github.com/OfficeDev/open-xml-docs/blob/main/docs/spreadsheet/working-with-formulas.md
- https://github.com/office-kit/xlsx/issues/115 (library issue; handwritten fixture, not Excel-created)
- https://github.com/ExcelDataReader/ExcelDataReader/issues/53 (library typed-string handling report)
- https://stackoverflow.com/questions/31255281/iferror-index-match-returning-zeros-instead-of-blanks (community Excel pattern)
- https://learn.microsoft.com/en-us/answers/questions/5343285/blank-cells-show-up-correctly-but-when-they-are-us (community explanation, not normative specification)

## Existing static reversed-reference geometry,11 November2026,11:28IST

Microsoft defines colon as all cells between two references, including both. The existing static parser retained reversed endpoint order and the range reader silently visited an empty rectangle. Authored fresh LibreOffice tests give SUM(A2:A1)=5, SUM(B2:A1)=14, SUM(B1:A2)=14 and SUM(B:A)=14 where baseline returned0. The secondary output retains reversed formula text, so this is not a serialization rewrite. Candidate and integrated results agree for these four numerical forms. The source-self-reference B3=SUM(B3:B2) returnsCIRC after canonicalization while LibreOffice givesVALUE: both errors, different codes, not nativeExcel parity.

Parser._range_from_words now canonicalizes min/max row/column bounds only for legal static cell rectangles and existing whole-column/whole-row forms, after existing explicit sheet/book identity checks. Formula strings, range sheet/book identities and all other parser behavior remain. No global RangeRef constructor change, dynamic INDEX/CellRef resolver change, new lexer syntax or illegal-geometry certification. Dynamic reversed endpoints still refuse with diagnostics. Existing $2:$1 row syntax is tested; unqualified numeric2:1 remains unsupported, even though the LibreOffice secondary fixture accepts it. An initial test wrongly assumed Data!2:1 was supported and was corrected to existing Data!$2:$1, not a feature expansion. Normalized geometry drives both reads and invalidation, including future occupied rows in whole-column ranges.

A pinned report-builder investigation exposed the gap: batchwise_cashflow.py SHAcd2730b99770f56ea993285272e8c17e2ff97cf1bbbc9a28203d4a851e8a6e99 at commit540918090b1b2c64efcb6472caffefacc17da6ff generates B3=SUM(B3:B2) for authored empty proto/V1 sections; baseline0/no notes masked a source self-reference. The actual archived output instead has SUM(B2:B3), already detected as a cycle. Do not attribute the archive to this pinned builder/version or claim a historical empty payload. One-supplier authored sections produce normal totals. This change detects reference geometry/cycles; it does not choose an empty-section report policy, change source formulas, replace totals or authorize a financial fix.

Twelve durable methods cover vertical/crosscorner/bothaxis/wholecolumn/existingwholerow reversal, bounded edit and future whole-column invalidation, self-cycle detection, retained static identity refusal, dynamic reversal refusal and absolute/casefold identity. Fresh full202plus21subtests18.27s/one known original warning, standalone195plus21/1.60s and smoke pass. Complete actual MAHLE25,597anchor comparison7.516s retains23,634exact/252matchingerrors/1,709nooracle/2selfcycles; no numeric-tolerance hits or new source repair. Two external cached books/cycles remain diagnostic blockers. Matching errors and absent cached values are not clean values, acceptance, nativeExcel/runtime proof or external freshness.

Evidence research/cashflow_empty/ retains pinned builder, authored empty/nonempty generated fixtures, baseline/candidate/integrated results, secondary source/output, full logs and durable-test source. Independent candidate review cleared this narrow static domain before adoption. Core change is parser helper/static construction only; Workbook/functions/evaluator and all existing test/CSVbytes unchanged. Original XLSX bytes unchanged. Earlier builder fixture0results remain dated baseline, not current output claims.

Change/removal note: replaced thecurrentbanner and reversed static endpoint storage with a canonical legal rectangle to avoid silent zero/incorrect dependency regions. Removed no source workbook formulas, financial/rounding rules, client rows or history.24/258/0and3.b.2/3.e25% remain, no client-case closure or production approval.

Sources:
- https://support.microsoft.com/en-us/excel/using-calculation-operators-in-excel-formulas
- https://github.com/solutionsDigibull/BuLLMQuote_SRIM/blob/540918090b1b2c64efcb6472caffefacc17da6ff/mcp-tools/reporting/superset/reports/batchwise_cashflow.py

## External cached-cell identity and explicit empties, 11 November2026, 11:20IST

Exact MAHLE externalbook2 Sheet0 B180 is declared t=str with value629001158, while ExInvVL1 A12 is numeric629001158. The old loader float-converted every external v before respecting its type, producing a spurious exactnumeric VLOOKUP match to this text identifier. Separately recovered QW source at B180 is text too. Present external cached G800/G805/G809 cells omit v; old import discarded them and later returnedREF for absent keys. A matching external text ID with explicit empty return value instead uses the snapshot's BLANK representation, not a fabricated missing-cache value.

Workbook.load now decodes once, directly from the already loaded external-link payload. No subclass/rebuild/secondload adoption: the reviewed candidate's storage decoder replaces the old unconditional float/drop-empty block. Declared str stays exact text, including leading zeros, numeric-looking and hash-prefixed strings; default/n accepts finite numeric values; b accepts only0/1; e accepts only the seven parser-supported Excel error codes. Unsupported/shared-string/date/inline kinds, malformed numbers/booleans/errors and newer unsupported errors returnREF plus diagnostic, not a guessed type. Present omitted-v cells becomeBLANK only for these four supported kinds. Absent positions/books remainREF, including actual externalbook1with no cached rows and book2G816. This is cached snapshot representation, never live source freshness.

Cell references must have legal bounds and match their parent ExternalRow.r. An initial candidate was HELD because it accepted arbitrary t=e text and A1insideparentrow2; both guards were refined and independently cleared before core adoption. Unsupported #SPILL/error strings remainREF with diagnostic rather than silently becoming supported errors. Twelve durable full-XLSX serialization tests cover the refined guards, type/lookup identity, presentempty/absent distinction, missingbook, boolean and malformed/unsupported values. Actual Workbook import is single-pass; functions/parser/evaluator and existing tests/CSV are unchanged. No network source fetch, cached formula-result substitution, source workbook modification, external-account access or selectedquote approval occurs.

Fresh full190plus21subtests18.83s/one original warning, standalone183plus21/1.64s and smoke pass. All25,597actualexport formulas traverse after integration in7.473s:23,634exact values,252matching saved errors,1,709no cached oracle,2different error-or-value, zero differentvalue or near-tolerance hits. Two remaining differences are actual BatchwiseCashflow B3=SUM(B2:B3), C3=SUM(C2:C3) versus savedtext0, not repaired. Compared with737,69fresh numeric/savedNA mismatches become matching errors by preserving text identifiers; one numericidentifier with explicit empty return now correctly does not match text, and two textidentifier empty returns useBLANK/zero display. Thus matchingerrors increased, not clean values certified. Nooracle has precedence and is never success. Evaluation stats25,595 vs25,597anchors still reflect2cycles. Loaded2externalcachedbooks andcycle notes keep release blocked. Eight selected cachecoordinate/type/value witnesses match the separately recovered QW bytes; no entirecache-source parity, chronology or historicalexecution identity is inferred.

Evidence: research/external_cache_types/ retains initial/refined/integrated states, source-cell witnesses, complete parity and test logs. Actual source hashes remain output1165ddb870f56d55c5a4ecb7a7b91aa5c9b59e0c50cbde43ec69c481659f6dfa and QW8d192a0a424f434043a0b03ec275f0ecebd51106282f41065d75849efeecc2bf. Original files unchanged. The relationship target's old SharePoint/filepath is data, not authority, current access or proof it is the live source. No relationship URL was followed. Seven supported errors are the existing parser set; no all-Excel-error claim.

Change/removal note: replaced current banner and the untyped external-cell coercion/drop-empty import, because it changed identifier types and erased explicit empty payload cells. Retained all dated baseline evidence and conservative unresolved references. No source formulas, client cases, history, financial rules, rounding policy, runtime bindings or source-owner files removed/changed. CaseCSV24/258/0 and3.b.2/3.e25% remain; no financial correction, client acceptance or production approval.

Sources read:
- https://learn.microsoft.com/en-us/openspecs/office_standards/ms-oe376/4aaab7f0-909a-4938-bf72-516151199cd9 (Officeexternalcell restrictions, including parentrow)
- https://schemas.liquid-technologies.com/OfficeOpenXML/2006/ct_externalcell.html (typedcell defaultn, optionalv; structural evidence not live-state proof)
- https://openpyxl.readthedocs.io/en/stable/api/openpyxl.workbook.external_link.external.html (serialization API/types)

## Canonical last-row LOOKUP and complete MAHLE export audit, 11 November 2026, 11:12 IST

The exact export SHA1165ddb870f56d55c5a4ecb7a7b91aa5c9b59e0c50cbde43ec69c481659f6dfa was traversed at all25,597formula anchors, not only selected totals. Baseline716 comparison:13,183exact values,182matching saved errors,1,709without cached oracle,1,644different values,8,879different error-or-value. This showed why the earlier12selected matches could not certify the workbook. Baseline audit completed7.491s with no exceptions, error outputs, external-cache warnings and two cycles. No-cache classification has precedence and can hide a fresh error:260baselinefresh errors fell in that category. Never count missing caches or matching errors as clean values.

First ExInv root: AK1 LOOKUP(2,1/(CBOM!C:C<>""),ROW(CBOM!C:C)) returnedNA while saved113. Existing LOOKUP resolved the ROW result vector as scalar, but its lookup vector had an occupied array prefix. A matching index could not fit that one-item result vector. The integrated helper recognizes only literal2, literal1 reciprocal of a single local whole-column <> empty-string comparison, and ROW of the identical whole-column reference. It evaluates the existing reciprocal comparison array and returns a symbolic matching row. The omitted unoccupied suffix contains only division errors, not numeric matches. Original logical full-range dependencies remain recorded, so future rows/formulas/errors invalidate correctly. Other LOOKUP inputs, general ROW arrays, external/bounded/multicolumn/mismatched-reference forms retain the existing fallback; no general vector widening or error suppression.

Eight durable test methods include six rejection shapes, text/number/zero/false, physicalBLANK and empty-string/formula-empty-string, error-valued lookup entries, allblankNA, future/restore/formula edits and casefold reference identity. An initial authored fixture stored PythonNone directly instead of the importer's BLANK sentinel; fixture storage was corrected, not engine logic. Seven fresh LibreOffice whole-column fixtures agree, secondary rather than native Excel evidence. Independent review also exercised row1,048,576value/error invalidation. Actual functions.py helper matches the cleared candidate AST, excluding helper name/imports. No source workbook changed.

Fresh integrated full suite178passed plus21subtests18.19s, one known original pivot warning; standalone171plus21/1.47s. All25,597export anchors traversed after integration in7.427s:23,632exact values,182matching saved errors,1,709no cached oracle,69different values,5different error-or-value. Existing numeric-within1e-9 branch has ZERO hits; no financial tolerance is approved. All69remaining value differences are ExInvVL1 external VLOOKUPs with savedNA versus fresh numeric values, not accepted truth. Five remaining errors are two actual self-cycles in BatchwiseCashflow B3=SUM(B2:B3), C3=SUM(C2:C3), and three externalREFoutputs. Formula evaluation stats25,595 vs25,597anchors reflect the two cycles, not skipped clean cells. Two external cached books and cycle diagnostics remain; no native Excel, correct external state, source-version execution or clean-release certificate follows. Missing oracle values remain unverified. research/lookup_lastrow/ retains baseline/candidate/integrated tests and results separately; research/mahle_output/full_parity.json stays baseline.

### Price Control source-version qualification

A fresh read of solutionsDigibull/BuLLMQuote_SRIM price_control.py at commit540918090b1b2c64efcb6472caffefacc17da6ff has SHA43149e267ea35d0a3fdf7ccf08a2ae3099c6b76dbca9412daca2b781bd869d1c, equal to current default content at inspection. Its only round calls compute two-decimal percentages. Its currency.py equals the retained pinned source and converts without four-decimal unit rounding; builder writes bounded live SUMPRODUCT, unlike the archived static category inputs. Therefore the earlier round4UNIT arithmetic fit is NOT bound to this Python routine, historical execution or client policy. Searches for the named PHP controller/export in accessible repos returned no matching code; the connected GitHub account cannot read AI-Engineer888NagabhushanaRajuS/CAM3.4 in this scope. These are bounded access/search results, not global absence or permission to switch accounts/deploy. Source/version/execution linkage remains a real gap.

Change and reason: replace the170/163current banner with fresh178/171evidence, add the reviewed narrow lastrow path and complete blocked audit, retain earlier selected successes/baseline failures as dated scope, and preserve external/nooracle/error limitations. Removed no client records, source formulas, history or financial policy.24named/258not individually analysed/0accepted and3.b.2/3.e25% unchanged; releasefalse.

Sources:
- https://support.microsoft.com/en-us/excel/functions/lookup-function (same-position/same-size vector contract; not native proof of reciprocal/error idiom)
- https://github.com/solutionsDigibull/BuLLMQuote_SRIM/blob/540918090b1b2c64efcb6472caffefacc17da6ff/mcp-tools/reporting/superset/reports/price_control.py
- https://docs.google.com/spreadsheets/d/1thNtdhP1aMDh201tVSAjvmWneiHdDqaC/edit?usp=drivesdk&ouid=101517642553279522776&rtpof=true&sd=true&authuser=nagabhushana.raju.s%40digibull.ai

## MAHLE source separation and guarded SUMPRODUCT, 11 November 2026, 11:02 IST

### Exact sources, not filenames

The old Internal workbook SHA7a7e04d10a6eb141c6c22a80cbb26559ffb8c30d3b2cf4a88859c285d94b59cc and actual archived output SHA1165ddb870f56d55c5a4ecb7a7b91aa5c9b59e0c50cbde43ec69c481659f6dfa are different evidence populations. Old Internal ACLASS has 88 data/cache records with unique typed CPN identities and exact key sets. Two contribution differences net +0.0012/+57.6, explaining that saved source/cache gap by Decimal arithmetic. All cache numeric contribution lies in visible Centum; three source labels are lowercase centum. Do not apply case-sensitive cache grouping to current source or infer refreshed grouping, chronology, app cause or policy. Ten selected engine anchors reproduced the old Internal values; no pivot refresh occurred. Evidence: research/mahle_totals/.

For the actual export, live provider downloads match source archive bytes. Summary D2 identifies CE-005641-AB, Rev-0, 11-Dec-2025 and assembly16553000. Checkpoint Summary A1 identifies Mahle; D6/N6 record Matrix/Summary and PriceControl/Summary Not Matching, and four copied numeric cells match output exactly. Local download suffix Checkpoints_Mahle electric (1).xlsx is NOT archive member identity: SHA9a4a3e709f444d754b02f25b3d77d27126cc33e5f2e7a40368a082b804d21045 maps to files/Checkpoints_Mahle electric.xlsx, not the distinct (1) member SHAeca76d89d337fd9a01e24f626ce75ec2b7164269636ee4be00efdcd3328a56f1. Archive BOM_Matrix_FILE.xlsx is excluded from Mahle analysis by its CE-005646/STN40472 content, despite folder placement. No authenticated historical mail/build/run linkage follows from these source-level bindings.

### Exported Matrix and Price Control witnesses

In each of three volumes, Matrix assembly row9 Unit Price-labelled K/N/Q lookups read CBOM K10=70, whose J10 label is Count of Total CPNs. It is NOT lead time. Matrix totals R7/S7/T7 include that70; detail rows10:96 sum to the saved Summary costs. This identifies the selected exported lookup/total mismatch mechanism, without approving a new aggregation or repair.

Correction: exported PriceControl B4/C4 are SUM formulas over static category inputs B2/C2, not themselves static. There are no exported PriceControl pivot objects. Its +26.6012903223 extended gap is not the old Internal +57.6 cache mechanism. Actual source Arow=C10 and AErow=AIrow select70 unique typed CPNs among88 detail rows, 18 excluded. The exclusions include assembly, packing, DNP and source-priced-not-selected rows; do NOT call all18 uncosted or substitute IsData truthiness/general dedup. All selected category labels are Centum;61USD/9EUR. Decimal sum of stored extended prices is22.9059541935483871274. Hypothesis ROUND_HALF_UP of converted UNIT price to4decimals, then quantity multiplication, totals22.9054 and times48000 gives1099459.2, matching static B2/C2. Rounding EXTENDED price instead gives22.9060. Twenty unit contributions change. This is an arithmetic fit only, not a unique algorithm, executed-code proof, approved financial rounding policy or fix. Source/version/execution binding remains open. Evidence: research/mahle_output/.

### Narrow integrated calculation change

Baseline selected12-anchor export run matched8 and failed4 Summary anchors with computed-blank-tail SUMPRODUCT diagnostics. The integrated helper admits only a direct same-sheet single whole-column argument plus whole-column arrays made from pure comparisons and unary +/-; each argument must contain a whole-column range. Scalar CellRef leaves remain eligible, including other local sheets; external scalar references do not. The direct argument's blank suffix is zero under SUMPRODUCT's nonnumeric-array rule. Every original full-column reference is recorded before a bounded occupied-prefix read, so future values/errors invalidate results. Errors in occupied inputs still propagate even when the direct guard is zero.

Functions, binary arithmetic, tables, dynamic/bounded/external/multicolumn/cross-sheet computed arrays retain prior fallback/refusal behavior. No-guard blank-tail counting remains unsupported; this is not all SUMPRODUCT support. Twelve durable tests cover scope, coercion, errors and future value/error invalidation. Five authored whole-column formulas match fresh LibreOffice secondary results, not Microsoft Excel. Independent candidate review cleared the exact narrow helper before adoption. Only functions.py and a new12-method test file changed in the calculation suite; parser/evaluator/Workbook remain unchanged.

After integration, all12 selected export anchors match in the source-checkpoint probe (2285formulaevaluations in its order), and a separate9-anchor probe matches with2283formulaevaluations/0.444s. These are distinct invocation orders/counts, not contradictory whole-workbook counts. Both retain external-links loaded2cachedbooks. Baseline failure evidence is retained separately, not overwritten as a prior pass. Saved historical/external-cache agreement is not independent Excel-runtime correctness. No source workbook was modified. Fresh full170/21subtests18.03s and standalone163/21subtests1.45s pass; smoke passes. Exact originals for seven optional source tests remain absent from the handoff; selected exported source/checkpoint evidence is bundled privately.

Changes and removals: replaced the current banner, corrected static-total shorthand and local-suffix/archive-member confusion, retained dated baseline failures and prior pivot evidence, and added only the reviewed calculation subset. Removed no source formulas, client rows, financial rules or history. Case CSV and counts unchanged. Source-level evidence does not close CAM129/131 or raise any milestone.

Sources:
- https://docs.google.com/spreadsheets/d/1thNtdhP1aMDh201tVSAjvmWneiHdDqaC/edit?usp=drivesdk&ouid=101517642553279522776&rtpof=true&sd=true&authuser=nagabhushana.raju.s%40digibull.ai
- https://docs.google.com/spreadsheets/d/1-z1HATeXO1bYRqdKk0Z0MK-yj0mkZ1dz/edit?usp=drivesdk&ouid=101517642553279522776&rtpof=true&sd=true&authuser=nagabhushana.raju.s%40digibull.ai
- https://drive.google.com/file/d/13-x5pQ2mFplLIl9diRh1imkZZCdkTlQw/view?usp=drivesdk&authuser=nagabhushana.raju.s%40digibull.ai
- https://support.microsoft.com/en-us/excel/functions/sumproduct-function

## Date census scope reconciliation, 11 November 2026, 10:30 IST

The exact difference between retained 4,786 DATEDIF sites and old class-report 4,706 is now reconciled by joining supplied date-site file IDs to the original `corpus/workbook_formula_summary.csv` duplicate flags. The reviewer independently checked unique summary keys, all retained date-site IDs and the join. Only the80sites in `1Sojje6izPDJ4M7fo1YQcY-0Dds2x5QVZ` are excluded as `DUP_OF_1gjkUTyDr9mQZAMFpzZaJ1HBAk2v_DEbh`; retained totals become4,706DATEDIF and26WORKDAY. `research/corpus_dates/duplicate_scope_reconciliation.json` records the exact summary SHA and selected-entry evidence. This supersedes the earlier statement that the exact scope difference was not reconciled; it does not change raw retained counts.

The original analytics defines duplicates by identical formula count/template count/sheet count, NOT content hashes, unique projects, input/cache equality or semantic equivalence. For ONLY this selected MAHLE pair, actual downloads separately verify exact1,301,909bytes and identicalSHA256 `7a7e04d10a6eb141c6c22a80cbb26559ffb8c30d3b2cf4a88859c285d94b59cc`. That does not validate the whole corpus heuristic. Retained-pair source: https://docs.google.com/spreadsheets/d/1gjkUTyDr9mQZAMFpzZaJ1HBAk2v_DEbh/edit?usp=drivesdk&ouid=101517642553279522776&rtpof=true&sd=true&authuser=nagabhushana.raju.s%40digibull.ai . The selected MAHLE actual-source probe remains valid regardless of the analytics exclusion. Complete underlyingCSV census was not independently rerun. No new engine tests/code/CSV/case/milestone change follows.

Change and reason: replace an unresolved denominator explanation with the independently checked actual join, retaining counts-based heuristic versus selected exact-byte proof distinction. Earlier dated raw-site evidence remains valid.

## Selected corpus date evidence, 11 November 2026, 10:26 IST

Research-only date consolidation is now in FE-5 under "Corpus date paths" and `research/corpus_dates/`. Retained substring-site census: 4,786 DATEDIF/18 entries (all unitM/TODAY->validity), 26 WORKDAY/2 entries, not unique projects or semantic coverage. Reviewer aggregated records, not full CSV rescan. Actual MAHLE80current-clockNUM results follow start>end semantics; saved37ones/43zeros do NOT establish a historical mismatch because original clock is unknown. Derived selected ETA fixture, NOT original full load, matches13saved source dates and26before/after expectations for an authored effort edit. Reviewer independently reproduced both actual-source probes; rebuilt derivedXLSX hash differs by serialization, so only semantic equivalence is claimed. Original source bytes unchanged. No source calendar/client ETA/quote policy invented.

Change and reason: strengthen source-bound date evidence without promoting research to a defect/fix/accepted case. No code/test/CSV change or fresh regression; 144standalone/dated140full,24/258/0 and3.b.2/3.e25% unchanged. See FE-5 for commands, hashes, source URLs and limits.

## Route reconciliation: 11 November 2026, 09:23 IST

24 named case-specific investigations / 258 not yet individually analysed / 0 client accepted, out of 282 first-pass routed rows. "Named" means a documented mechanism or policy investigation beyond the first-pass issue/expectation read. It does not mean a corrected implementation, independently verified expected output or client closure. The per-case evidence-level column is authoritative for those distinctions.

At the dated06:54checkpoint, five routes were added: CAM-181, CAM-182, CAM-183, CAM-184 and CAM-207. CAM181-184 have source/raw/report quantity-population evidence and isolated nullable-key variant probes; CAM207 has source-record versus output-presence comparison-grain evidence, selected formula-cache checks and current-source synthetic probes. CAM185/186 were already named and receive stronger actual packing-candidate evidence without increasing the count. All seven retain exact deployed/source/edit and approved-output gaps in the CSV. Existing requirements are not missing policies: Carry source qty applies to the unique181-184 associations;185/186 already specify0.2/0.0125. No financial rule or correction was invented.

Change and reason: retired the stale current17/265 bookkeeping because completed source-backed investigations were not reflected in the map. The dated17/265 CSV baseline is preserved in `docs/history/client_case_acceptance_map_2026-11-11_0652.csv`; exact before/after case IDs, definition and evidence upgrades are in `case_route_reconciliation.json`. Historical log counts below remain dated history, not current totals. At the06:54reconciliation no core code/test change occurred; current07:37integration is separately recorded below. No3.c or other stage completion follows.

## Retained prior calculation summary (superseded): 11 November 2026, 09:32 IST

Local research prototype v0.1.0, not client accepted or production ready. Full local suite:88passed,17.36seconds,1originalpivotCachewarning. The standalone suite excludes seven optional private-source experiments:81passed,0.95seconds; a fresh ZIP extraction passed81in1.14seconds plus smoke and the synthetic hash-bound edit fixture. `README.md` gives runnable commands, `engine/smoke_check.py` is source-independent and `engine/audit_workbook.py` reports diagnostic gates.

| Source | Exact historical values | Matching historical errors | No cached oracle | Explicit unsupported outputs | Total |
| --- | ---: | ---: | ---: | ---: | ---: |
| MKU Internal | 5,504 | 12 | 16 | 0 | 5,532 |
| TOPPLATE Internal | 33,810 | 310 | 486 | 6 | 34,612 |
| CAM205 archive candidate | 8,047 | 0 | 458 | 1 | 8,506 |

This current table supersedes the earlier33816exact/zeroUnsupported TOPPLATE result. Three ACLASS table SUBTOTAL109 formulas and three dependent outputs now refuse active-filter semantics, instead of treating saved hidden-row snapshots as edit-correctness proof. The affected cells are ACLASS PARTS!I3,K3,R3,I185,K185,R185. CAM205 similarly refuses Ex Inv VL-1!AM3, which previously computed313.97302105263145 against historical43.7. Actual filter refresh remains unfinished. Filter headers are outside the filtered data region; tests check header-only, first data row, last data row, mixed header/data and just-after-filter references. The row-wide guard is deliberately conservative.

TOPPLATE all calculated values/dependencies were reset after rebinding actual original XLSX filter metadata; model/AST retained, not diskcoldstart. Current scoped inventory:34612anchors,199987cell/61154rangeedges. Test05computes27692absent-cache outputs without errors; not value parity. Historical/pivot/external-cache compatibility is not independent Excel certification.

The complete CAM205audit in `cam205_current_release_gate.json` records one unsupported output AND four `_XLUDF.NUMBERVALUE` diagnostics caught by outer formulas. Masked failures still block release. Inspect diagnostics, not only final error counts or #VALUE! vs #NAME? codes. A calculation error code is not a support classification. `release_ready` stays false: client expected values, financial policies, source/runtime bindings and deployment approval remain open.24 named case-specific investigations / 258 not yet individually analysed / zero accepted; no overall3.b/c/d/ecompletion.

Why this revision: withdraw accidental filter-snapshot certification, make masked diagnostic gates executable, and separate current facts from dated history. Exact optional-test originals and pickles are not supplied; private client-derived oracle workbooks/source extracts ARE included in the archive, so keep it private.

Sources: https://support.microsoft.com/en-us/excel/functions/subtotal-function ; https://support.microsoft.com/en-us/excel/get-started/filter-data-in-a-range-or-table-in-excel . Microsoft documents header data is not filtered, enabled-vs-applied filters, and reapplication after changed data/formulas. No guessed filtered-vs-manually-hidden classification was adopted.

## Sources and scope

Existing reverse-engineering folders (1)-(4), including cell_level_index.csv, workbook_formula_summary.csv, 4_analytics_report.md, authored formula strings, 16 logic documents and the extracted cell corpus. Master client-case source is Sheet 152HAJt9dKJ-8h-5N3trMmnmCaJoYpb6y_6zYPePf5x4, 282 rows. Source files were not edited.

364 workbook extraction files were read; 187 contain formulas. Raw copies contain 8,324,692 formula cells and 2,125,399 distinct exact formula strings. Copies are included deliberately. These are not 8.3M independent financial rules. The earlier normalized shape count (3,011) was an exploratory metric, not proof of raw parsing or semantic equivalence.

## Corrected method

The initial corpus_revalidation.txt is retained as an audit trail, not current truth. Its external metric tested for any '[' and therefore mixed tables with external links. Its function regex also treated BOM in quoted sheet names as a function, missed single-character N, lowercase spellings and prefixed names, and counted occurrences rather than containing cells. Those claims are retracted. The 197x comparison was wrong.

The replacement typed_census.py runs the actual formula lexer on each distinct raw string with its exact cell multiplicity. Function-containing cell counts are separate from function call occurrences. Quoted sheet names, string literals, table selectors and external prefixes have distinct token types. Dependency node counts come from a full parsed AST traversal, not a text search. All 97 unparseable cells stay in the denominator.

## Typed census

{
  "cells": 8324692,
  "distinct_formulas": 2125399,
  "features": {
    "external_workbook_cells": 8806,
    "structured_table_cells": 905839,
    "today_cells": 4786,
    "volatile_cells": 4786
  },
  "dependency_nodes": {
    "RangeRef_cells": 4650825,
    "RangeRef_occurrences": 14238121,
    "CellRef_cells": 7639481,
    "CellRef_occurrences": 24759988,
    "DynRange_cells": 826631,
    "DynRange_occurrences": 1959669,
    "TableRef_cells": 905839,
    "TableRef_occurrences": 2283332
  }
}

Dependency node categories overlap: a formula may contain CellRef, RangeRef, TableRef and DynRange. Counts ending in _cells count each containing formula cell once per category; _occurrences count every node multiplied by cell multiplicity. These are structural reference coverage counts, not proof that every possible runtime dependency has been recalculated.

## Function coverage

54 literal function identifiers occur. Stripping only the documented _XLFN. compatibility prefix leaves 48 spellings: 47 built-in names plus _XLUDF.NUMBERVALUE. The current engine registers 70 names, not the previously reported 47 (the historical census registry contained 68 before N was added). Registry presence is not complete semantic support. GETPIVOTDATA now supports only metadata-bound saved grand-total lookup, not pivot refresh or item pairs. At the original census checkpoint, N and WORKDAY were not registered. N and scoped modern-date WORKDAY were subsequently implemented. _XLUDF names are not assumed equivalent to a built-in. _XLFN prefixes resolve only to an already registered built-in.

| Identifier | Cells containing call | Call occurrences |
|---|---:|---:|
| IF | 3,752,519 | 5,879,468 |
| INDEX | 3,378,390 | 8,997,744 |
| MATCH | 2,821,206 | 4,371,055 |
| IFERROR | 1,635,189 | 2,597,908 |
| AND | 930,466 | 1,263,895 |
| VLOOKUP | 609,025 | 609,025 |
| NOT | 597,432 | 708,709 |
| SUMIFS | 530,048 | 534,181 |
| OR | 417,825 | 419,301 |
| MAX | 404,081 | 404,081 |
| ISERROR | 333,284 | 333,284 |
| COUNTIFS | 331,800 | 331,800 |
| ROUNDUP | 313,875 | 313,875 |
| UPPER | 265,021 | 265,295 |
| TRIM | 251,300 | 251,642 |
| CONCATENATE | 215,402 | 215,402 |
| SUM | 198,703 | 198,716 |
| SUBSTITUTE | 162,876 | 325,752 |
| INT | 152,592 | 152,592 |
| LEFT | 146,241 | 146,241 |
| FIND | 146,241 | 146,241 |
| LEN | 144,386 | 288,772 |
| NA | 139,895 | 139,895 |
| ROUND | 131,187 | 262,321 |
| AVERAGEIFS | 130,160 | 130,160 |
| TEXT | 114,404 | 457,298 |
| _XLFN.SUMIFS | 81,812 | 85,618 |
| SUMPRODUCT | 66,418 | 66,482 |
| COUNTIF | 37,408 | 37,408 |
| _XLFN.COUNTIFS | 26,488 | 26,488 |
| ABS | 21,050 | 21,050 |
| VALUE | 18,490 | 18,490 |
| _XLFN.AVERAGEIFS | 12,906 | 12,906 |
| ISNA | 12,298 | 24,596 |
| ROW | 7,665 | 7,761 |
| DATEDIF | 4,786 | 4,786 |
| TODAY | 4,786 | 4,786 |
| IFS | 2,907 | 2,907 |
| SUBTOTAL | 2,391 | 2,391 |
| _XLFN.IFS | 1,876 | 1,876 |
| _XLFN.NUMBERVALUE | 974 | 974 |
| NUMBERVALUE | 854 | 854 |
| MIN | 733 | 733 |
| GETPIVOTDATA | 643 | 643 |
| COUNT | 414 | 414 |
| SUMIF | 235 | 235 |
| LOOKUP | 162 | 162 |
| LOWER | 95 | 149 |
| ISBLANK | 51 | 51 |
| N | 44 | 44 |
| _XLUDF.NUMBERVALUE | 27 | 27 |
| WORKDAY | 26 | 26 |
| UNIQUE | 22 | 22 |
| _XLFN.UNIQUE | 1 | 1 |

## Reconciliation cautions

8,806 raw formula cells contain a typed external-workbook reference, and 905,839 contain table references; these overlap and must not be added. 4,786 raw formula cells contain TODAY. The published report uses deduplicated and filename-based classes in several tables, so its 4,646 selected external-reference count and 4,706 Internal volatile count are not directly comparable to whole-corpus raw totals. feature_counts_by_file.json preserves per-file IDs, paths and duplicate flags. Reconciliation now established by per-file aggregation: Internal-name raw TODAY=4,786, unique TODAY=4,706 (80 removed with duplicate copies); Internal-name external raw and unique=1,301. Published QuoteWin selection=3,345 and Internal selection=1,301 sum to 4,646. Whole-corpus raw external=8,806 includes other filename classes and copies, so the prior discrepancy is not a source-document error. No correction to those published class-specific counts is needed.

## What dependencies the implementation tracks

At evaluation, direct reads and bounded/whole-row/whole-column ranges record reverse dependencies. Table references resolve to ranges; dynamic INDEX endpoints are evaluated and then tracked. Edits invalidate transitive consumers. Whole-column dependencies cover the full legal row extent for invalidation even when evaluation is clamped to used rows. Conditional branches add dependencies when taken; historical dependency edges are retained, which can over-invalidate safely but grow memory. External caches are snapshot inputs and are not live subscriptions. Defined-name formulas, automatic table resizing, spill output, structural row insertion, filtered SUBTOTAL visibility, pivots and full Excel compatibility remain outside verified scope.

Change note: replaces misleading earlier external/function interpretations; preserves original logs and source documents. No client financial rule was changed.

## Semantic coverage per corpus built-in (review correction)

The 47 corpus built-ins below are canonical names after removing only _XLFN. prefixes. The 70-name registry includes extra entries outside the corpus, not 70 aliases for these 47, and is not a semantic pass count. _XLUDF.NUMBERVALUE is a separate literal identifier and is not normalized. Every implemented entry remains a tested subset, not universal Excel support.

| Canonical built-in | Current scope |
|---|---|
| ABS | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| AND | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| AVERAGEIFS | Criteria-first selected numeric reads, cross-sheet occupied-union blanks and known shapes tested. Unknown shapes/coercion/huge scans not certified. |
| CONCATENATE | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| COUNT | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| COUNTIF | Known reference geometry and explicit-empty-string tail tested. Numeric-zero/empty-tail and unknown logical reference geometry are explicitly unsupported; broader criteria/wildcards not fully certified. |
| COUNTIFS | Known logical shape check and empty-string common tail tested. Numeric-zero/empty-tail and unknown reference geometry explicitly unsupported; broader coercion not fully certified. |
| DATEDIF | Modern numeric1900-systemserials >=61, D/M/Y. Other units, early serials,1904 and text-date inputs explicitly unsupported. |
| FIND | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| GETPIVOTDATA | Saved visible grand-total lookup from actual pivot metadata/display cell. No pivot refresh, item/filter pairs or broader layouts. |
| IF | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| IFERROR | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| IFS | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| INDEX | Selected reference and observed array forms tested; reference unions not supported. |
| INT | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| ISBLANK | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| ISERROR | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| ISNA | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| LEFT | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| LEN | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| LOOKUP | Partial legacy lookup; approximate text/order behavior not certified. |
| LOWER | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| MATCH | Exact lookup and tested escaped star/question/tilde text patterns. Approximate modes, long text and broader coercion need wider verification. |
| MAX | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| MIN | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| N | Implemented scalar/array numeric identity and coercion; synthetic LibreOffice fixture and CBOM use tested. |
| NA | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| NOT | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| NUMBERVALUE | Tested explicit decimal/group separators and caller defaults; format/locale boundaries remain. _XLUDF.NUMBERVALUE is not aliased to the built-in. |
| OR | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| ROUND | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| ROUNDUP | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| ROW | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| SUBSTITUTE | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| SUBTOTAL | Selected codes/nested-subtotal exclusion/manual-hidden behavior tested. Active filter regions or unresolved reference provenance refuse with diagnostics; no filter reapplication. |
| SUM | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| SUMIF | Direct/table reference top-left shape alignment and criteria-first selected reads tested; computed-array reference shapes unsupported. |
| SUMIFS | Criteria-first selected reads, cross-sheet occupied-union blanks and known shapes tested. Avoids excluded self-dependencies; unknown shapes/coercion/huge scans not certified. |
| SUMPRODUCT | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| TEXT | Partial: observed numeric formats and array input; no general locale/date format engine. |
| TODAY | Fixed injected1900-systemdate;1904 explicitly unsupported; historical source calc date unknown. |
| TRIM | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| UNIQUE | Explicitly unsupported in all contexts. The former flatten/scalar behavior was withdrawn because it could return a plausible wrong value; no spill contract. |
| UPPER | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| VALUE | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| VLOOKUP | Implemented observed subset; unit/cached-workbook coverage is not full semantic certification. |
| WORKDAY | Modern numeric serials >=61 in 1900 date system; signed/truncated days, supplied holidays, weekends. Early serials,1904,text-date parsing and abs(truncated input day count)>36600 unsupported. |

Evidence labels: the 16 logic documents were staged as source inputs, not independently re-reviewed by the document reviewer. Counts from typed census are implementation output, not reviewer-recomputed facts. FE-4 is intentionally reserved for an eventual deployment/integration contract; no FE-4 artifact exists because production integration is not authorized or validated. This is numbering reservation, not missing completed work.

Change note, latest implementation: N is now registered, so the registry at that historical N checkpoint contained 69 entries; the historical typed census file records 68 at census time. Corpus names did not change. N is no longer in the unimplemented list.

## Current scoped dependency inventory

All34612TOPPLATEanchors have runtime records:199987cell+61154rangeedges. Staticnodes41284TableRef/51131CellRef/37233RangeRef/180external. No parse failures in this workbook. Original model/AST retained after sourceXMLfiltermetadata rebind and calculated-value/dependency reset; actual paths only, not all corpus/model lineage. See `topplate_dependency_inventory_summary.json`.





## Current private engine build: 11 November 2026, 09:32 IST

Current private-local regression evidence is **123 full tests in 18.19 seconds** (same original pivot warning) and **116 standalone tests in 1.45 seconds**, not client/stage acceptance. Three AVERAGE direct-cell test functions are added over the dated120/113build. The preceding MIN/MAX change added six parameterized instances from three functions over114/107. MIN/MAX now ignore text, logicals and blanks from direct CellRef arguments while preserving numeric zero, errors, direct literals, arithmetic values and edit dependencies. AVERAGE now likewise ignores text/logicals/blanks from direct CellRef while keeping zero/errors and dependencies. Its direct-literal semantics, general returned-reference/INDEX provenance and AVERAGEIF remain outside this patch. The recorded formula corpus has zero AVERAGE calls; this is registered-function hardening, not demonstrated client-formula coverage. Existing supported INDEX geometry and SUMIF dynamic anchor alignment are unchanged; unsupported geometry remains refused. Named investigations remain **24 / 258 / 0 accepted**. No client rule or production system changed.

Change and reason: extend only the primary-source-backed direct-cell reference filter to AVERAGE. Shared numeric conversion, literal and returned-reference semantics are unchanged. Replace current MIN/MAX-only summaries in place; retain that dated contract once in the existing history instead of appending duplicate build reports. The prior FE3 build text and original source/manifest are retained in existing history/research. Earlier client-workbook parity remains dated, not a fresh full evaluator replay. FE-3 owns the narrow contract; FE-5 records tests/source-census limits; FE-7 owns unresolved evidence gates.


Style-source reconciliation09:23: CAM188/194 now have actual rule/cache and visually checked derived-fixture evidence, not a missing-rule repair or client acceptance. 24 named / 258 not individually analysed / 0 accepted. Details and exact remaining screenshot/version/runtime gaps are in FE-2, FE-5, FE-7 and research/style_case_probe/source_rule_probe.json. At the dated09:23style checkpoint, code/regression114/107wasunchanged; original source files were not altered.

## Historical change log

Dated snapshots below are retained evidence only. Their words "current", "latest" and "supersedes" apply at that historical time, not to this checkpoint. The current table and manifest above control today.

### 03:38 scoped dependency inventory

`topplate_dependency_inventory.json.gz` adds exact per-anchor static reference nodes and observed runtime edges for all 34,612 original TOPPLATE formula anchors. Every anchor has a runtime record. Edges: 192,668 cells and 61,154 ranges; static nodes: 41,284 table, 51,131 cell, 37,233 range and 180 external. No parse failures in this workbook. Ranges remain rectangles. Runtime reads cover selected historical paths; static references also include inactive branches. External references are statically listed but not local edit-invalidating runtime keys, because they use historical snapshots. Generator-derived literal lineage is unknown unless separately sourced. This is one workbook's scoped inventory, not full 8.3-million-cell corpus dependency coverage and not CAM 3.4 runtime binding. Extraction script and summary are retained.

03:44 update: inventory regenerated after metadata-bound saved-pivot lookup; cell-edge count includes pivot display-cell dependencies. No refresh dependency is inferred.

03:51 inventory version caveat: saved runtime edges are historical with pivot/count consumers refreshed. Some unaffected edges predate the bounded unused-rectangle invalidation fix. The static AST bounds are retained; no fresh full runtime-graph rebuild is claimed. See FE-3/FE-5 and inventory summary.

### Full current-code TOPPLATE reevaluation, 03:58 IST

Completed all 34,612 original anchors after clearing **all computed value caches and local dependency graphs**, retaining the unchanged original workbook model and parsed ASTs. Bounded recalculation batches reevaluated exactly 34,612 formula cells (statistics delta), with 57,519 evaluation attempts and 180 external snapshot reads. Result: 33,816 exact values + 310 matching Excel errors + 486 absent caches = 34,612; no other mismatches, unsupported outputs or observed runtime cycles. This supersedes the earlier 03:54 caveat that the latest SUMIFS change had not been run on TOPPLATE. Saved pivot display/external cache inputs remain historical; this is not fresh independent Excel or financial verification.

`topplate_aggregation_results.json` records the full result and baseline-subtracted statistics. Repeated root-by-root invalidation initially hit a 60-second initialization limit; no comparison checkpoint had landed. The completed run instead used a single bulk cache/graph reset and bounded read budgets with resumable checkpoints. Aggregate wall-clock, disk-load cold start, peak memory and production concurrency are unmeasured. Do not turn unit-suite or batch timing into an SLA.

`topplate_dependency_inventory.json.gz` was rebuilt from this complete current-code runtime graph. All 34,612 anchors have records: 192,668 cell edges and 61,154 range edges, including original sum-reference dirty geometry. The earlier 59,128-range-edge mixed historical inventory is superseded. Static nodes remain 41,284 table / 51,131 cell / 37,233 range / 180 external. This graph covers actual selected branches in the saved source snapshot, not all branches, full corpus, external live refresh or generator-derived literal dependencies.

04:00 current registry is 70 entries after scoped WORKDAY, not70fullysupportedfunctions. Official source https://support.microsoft.com/en-us/excel/functions/workday-function and independent secondary fixtures support modern1900-systemnumericdate behavior. No client validity/lead-time policy inferred.

04:04 SUMIFselectedreads/shapealignmentfixindependentlytested,58currenttests. Zero directSUMIF/WORKDAYcallsinoriginalTOPPLATE;03:58completegraph/resultretainedwithversionqualifier.

04:08fullcurrent-codeTOPPLATEruntimegraphreevaluatedafterwildcard/SEARCHfixes, unchanged192668cell/61154rangeedges. Rawcorpusandtypedcensuscountsunchanged.59currenttests. Operator-prefixedwildcardcriteriaandUnicodecompatibilityversionsremainuncertified.

04:13all97rawfailurelocatorsverifiedin4originalXLSXfiles:allformula-typed,allcachedtext#ERROR!(XMLt=str,nottypederror),91description-like/6bareplus. Countsunchanged,noautomatictextrepair. Current61tests, typedsourceerrorcodespreserved, COUNTIF(S)unknownreferencegeometryexplicitunsupported.

04:16originalXMLcachetypeclarification:all97failurecachesaret=str#ERRORtext, nott=eerrors. Originalfixtureensuresengineparseerrornotfakematchedtocachetext.62testswith1sourcepivotCachewarning. FullTOPPLATEcurrent62codevalue/dependencycache-resetreevaluationcompleteunchanged, graphregenerated.

### XLOOKUP safety boundary, 04:18 IST

Review found that the old registered XLOOKUP handler ignored match/search modes and reused MATCH wildcard behavior for default exact matching. It could produce a plausible wrong result. Default exact matching now treats `*`, `?` and `~` literally. The verified subset is forward exact lookup over same-shape one-dimensional direct or table references, with lazy retrieval of the selected return cell. Tests cover duplicates, literal stars, horizontal lookup, missing-value fallback, omitted optional arguments, selected-cell edits and self-exclusion without a false cycle.

Nondefault match/search modes, computed reference arrays, multidimensional outputs, lookup-array blanks/errors and unmaterialized logical blank tails are explicitly unsupported with a diagnostic and `#NAME?`. Declared shape mismatches return `#VALUE!`. This is a deliberately narrow scope, not full XLOOKUP support. The Microsoft syntax distinguishes default exact match from wildcard mode2 and reverse/binary search modes: https://support.microsoft.com/en-us/excel/functions/xlookup-function.

Historical04:18suite:64 tests pass in14.22seconds, with the original pivotCache warning retained. At04:18 the full TOPPLATE62-test-code result was the most recent full replay; the typed raw census contains no XLOOKUP calls, so this safety change does not claim additional corpus coverage. No client case was closed. Source verification for the97parse-failure cells is now reproducible directly from OOXML and fixed source IDs/filenames, without temporary download metadata. The script verifies exact formula strings, cache type/value and original file hashes.

### Modern numeric date safety, 04:23 IST

Review found unguarded date conversions could throw exceptions on extreme serials/years, DATEDIF MD used an unverified shortcut, and NOW returned midnight despite no time-of-day clock. These no longer produce guessed values. DATEDIF supports modern numeric1900-systemserials from61 through2958465, with D/M/Y units. DATE normalizes month/day overflow, truncates numerical components, applies the documented0..1899year offset, and checks invalid year/date bounds. YEAR/MONTH/DAY use the same scoped modern serial validation. Early1900 dates,1904workbooks, nonnumeric date parsing and DATEDIF MD/YD/YM units remain explicit unsupported cases. NOW returns an unsupported diagnostic, not a false current timestamp. TODAY remains an injected date and explicitly rejects1904workbooks.

The synthetic `oracles/in/date_modern_numeric.xlsx` fixture checks modern month ends, leap-day anniversaries, day/month/year differences, component truncation, date overflow and date-part extraction. Tests match the enumerated secondary LibreOffice outputs, but four material disagreements are kept in `oracles/date_modern_numeric_results.json`: LibreOffice returned #VALUE! for reversed DATEDIF dates and negative DATE year, #VALUE! for DATE(108,1,2), and numeric2958466 for DATE(10000,1,1). Microsoft explicitly specifies #NUM! for reversed DATEDIF dates and invalid years, and January2,2008 for DATE(108,1,2); the tests follow those documented rules, not the conflicting secondary output. The serial39449 was independently computed from the documented calendar date. Early1900 and year10000 behavior from LibreOffice is not used as Excel proof. YM is rejected because documentation wording and a complete-month interpretation need an independent Excel check.

Sources: https://support.microsoft.com/en-us/excel/functions/datedif-function ; https://support.microsoft.com/en-us/excel/functions/date-function ; https://support.microsoft.com/en-us/excel/date-systems-in-excel . These are formula/date semantics, not approval of a client validity-extension or lead-time policy. No CAM case is accepted from a synthetic fixture.

Current66tests pass in13.98seconds, with1original pivotCache warning. Fresh MKU remains5504exact+12sameerrors+16nocacheof5532. Test05 still evaluates27692nocacheanchors without errors, not a value-parity result. Full TOPPLATE66-test-code value/dependency reset completes34612anchors:33816exact+310sameerrors+486nocache,zero other mismatches/unsupported outputs/observed cycles. `topplate_date_results.json` is the current full replay; model/AST retained, not a fresh disk-load benchmark. Runtime inventory is regenerated from that graph. Earlier62/64-test checkpoints are history, not current pending work.

### CAM189 blank-scrap error mechanism and current replay, 04:34 IST

The master Source mails row148 lists `CBOM_Report_CE_005864_20260916_112632_b321ceda.xlsx` for message `1a0aa099cfa9670d`. The archived candidate `1fnrDKIvj0eo-S_mErHpiAvylAV7P9p69` is an exact filename match, not independently hash-bound to original attachment bytes or screenshot. Its source SHA256 and exact metadata/locators are retained in `cam189_blank_scrap_source_probe.json` and `cam189_source_binding.json`.

In both Ex Inv sheets, AJ5 selects index12 from data starting row25, binding K5 to matching report AK36. `7.0 CBOM VL-1/VL-2!K36` price is formula-empty text; AK36 therefore returns empty text for scrap. Ex Inv K5 successfully returns that empty text through INDEX, so IFERROR does not substitute0. L5 and N5 then evaluate arithmetic `1+K5` and return #VALUE!, propagating to AB5. Engine computes24sucherrorcells inVL1 and18inVL2. A separate LibreOffice recalculation of the unchanged candidate produces the exact same42errorcells. Original saved non-error outputs differ and are not substituted for execution. This is a real source mechanism reproduction, not proof of original screenshot identity, a financial fix or client acceptance.

Full candidate workbook parity remains separately reported:7985anchors=6670exact+455tolerancematches+802nocache+42computederrorsagainstnonerrorcaches+16othermismatches. No matching-error result is claimed against its historical caches. No source formula was changed to insert a blank-to-zero default. That policy still needs owner approval.

Current69tests pass in15.24seconds with1originalpivotCachewarning. Test69 adds the candidate regression only, no engine code change since68. Full68-implementationTOPPLATE replay is now complete:34612anchors=33816exact+310sameerrors+486nocache,zero other mismatches/unsupported outputs/observed cycles. All formula values/dependency graphs reset; model/AST retained. Current graph regenerated192668cell/61154rangeedges. Fresh MKU/Test05logs from68implementation unchanged. No full-corpus/client/prodclaim. Namedcasecounts remain17/265/zeroaccepted because CAM189 was already a named route.

Source candidate: https://docs.google.com/spreadsheets/d/1fnrDKIvj0eo-S_mErHpiAvylAV7P9p69/edit?usp=drivesdk&ouid=101517642553279522776&rtpof=true&sd=true&authuser=nagabhushana.raju.s%40digibull.ai

### CAM192 static lead-time counts, 04:36 IST

The same filename-matched September 16 candidate contains another distinct mechanism. A hypothetical last-volume edit, `7.0 CBOM VL-2!S25` from 4 to 10 for CPN `LM1000013`, changes formula-dependent `Ex Inv VL-2!U14` from 4 to 10. The FG-wise 4-week count at B3 stays 8, its B13 total stays 32, and consolidated B3 stays 11. Those count cells are numeric literals. The FG-wise sheet has no formulas or pivot metadata; the consolidated sheet has 13 formulas that derive totals/percentages from literal counts, not from report lead-time cells. There is no formula dependency to invalidate for these snapshots.

An independently recalculated LibreOffice copy with the same hypothetical edit agrees on all six recorded input/output cells. Original source bytes are unchanged. `cam192_static_lt_snapshot_probe.py/json` retain exact source hash, locators, formula/literal types and evidence limits. The 10-week value is a mechanism probe, not the actual client edit or a proposed policy. Cross-FG and cross-volume counting/deduplication rules and original screenshot/attachment identity remain open. No bucket counts were regenerated or written back. This contrasts with the later CAM199 candidate, where bucket formulas do exist and respond to edits; behavior must be bound to the actual source/version, not generalized across files.

Current local suite: 70 tests pass in 15.91 seconds, with one original pivotCache warning. Six private original/candidate fixture tests skip when their source files are absent. The 70 registered function names are a separate count, not 70 fully supported functions. No implementation files changed after the complete 68-test-code TOPPLATE replay; tests 69 and 70 only add source-case fixtures. `implementation_manifest.json` records current source hashes and the relationship between tests, registry and replay. Named routes remain 17; 265 cases are not individually analysed; zero are client validated.

### SUMPRODUCT dimensions and value types, 04:42 IST

Review found that the old handler broadcast mismatched arguments and converted numeric-looking text and logical values into numbers. The handler now checks equal declared direct-reference dimensions before summing. A scalar argument does not broadcast across a larger array. Direct-reference blank tails can be padded with zero only after shape checks. Nonnumeric array entries, including numeric-looking text and uncoerced logicals, contribute zero; arithmetic or double unary inside the formula still explicitly converts them. Errors propagate.

A computed expression over a reference whose blank tail was not materialized is now explicitly unsupported. For example, `SUMPRODUCT(--(A1:A100=""))` must not count only the occupied subset. Direct numeric `SUMPRODUCT(A1:A100)` can safely omit blank zeros and still tracks the whole reference for growth. Tests cover those cases and mismatched row counts, row-vs-column shapes, scalar arguments and future input growth. This is not full certification of every computed-array shape or dynamic-array compatibility version.

Microsoft documents equal dimensions and nonnumeric entries as zero. The LibreOffice fixture agrees on dimension errors and explicit arithmetic errors but counts uncoerced TRUE as 1, unlike the documented Excel behavior. This conflict is retained: sample results 53/7/53/1 in LibreOffice correspond to expected Excel semantics 46/6/46/0. Exceljet independently demonstrates that an uncoerced logical array sums to zero and double unary is needed. We follow the documented Excel rules, not this secondary-oracle difference. No fresh Excel runtime proof is claimed.

Sources: https://support.microsoft.com/en-us/excel/functions/sumproduct-function ; https://exceljet.net/articles/the-double-negative-in-excel-formulas ; https://support.microsoft.com/en-us/office/use-sumproduct-to-sum-the-product-of-corresponding-values-in-one-or-more-arrays-ae55584b-ecf7-4a83-b108-1ab774d29256 . Fixture, output and conflict notes are retained in `oracles/sumproduct_dimensions_results.json`.

Current local suite: 72 tests pass in 15.78 seconds with one original pivotCache warning. Fresh MKU remains 5,504 exact + 12 matching errors + 16 absent caches out of 5,532. Test05 still computes all 27,692 absent-cache anchors without errors, not value parity. Full current 72-test-code TOPPLATE reset completes all 34,612: 33,816 exact + 310 matching errors + 486 absent caches, with zero other mismatches, unsupported outputs or observed cycles. Current graph is regenerated from `topplate_sumproduct_local_checkpoint.pkl` and source hashes are updated in `implementation_manifest.json`. Original model/AST retained, not a fresh disk-load benchmark. No financial policy, source rewrite or case acceptance changed.

### NUMBERVALUE conversion and explicit separator configuration, 04:47 IST

The old handler removed every group separator regardless of position and relied on Python float parsing. It missed documented empty-text, internal-space, repeated-percent and first-character separator rules. NUMBERVALUE now checks one decimal separator, rejects a group separator after it, ignores group separators before it, ignores ASCII spaces, returns 0 for empty text, and applies each trailing percent sign. Tests include the Microsoft examples `2.500,27` with comma decimal/period group -> 2500.27, and `9%%` -> 0.0009. Multi-character separator arguments use their first character. Invalid numeric text such as NaN/Inf is not accepted as a financial number. Empty/space decimal separators, unusual separator characters and overflow remain explicitly unsupported rather than guessed.

Omitted separators still need a locale contract. The public constructor now exposes `Workbook(path, decimal_separator=".", group_separator=",")`. These compatibility defaults preserve the prior prototype configuration; they do not prove a source workbook's locale. Callers can explicitly select comma decimal/period grouping. Invalid configuration is rejected. Source locale discovery, broad VALUE/localized date parsing and `_XLUDF.NUMBERVALUE` identity remain unresolved. The user-defined spelling is not silently aliased to the built-in.

The independent LibreOffice fixture required the standard `_xlfn.` XLSX compatibility prefix; the initial unprefixed import returned #NAME? for every test and is not treated as conversion evidence. With the prefix, most cases match. Two direct disagreements with Microsoft documentation remain recorded: LibreOffice returns #VALUE! for empty text and for multi-character separators, while Microsoft explicitly specifies 0 and first-character handling. NaN also gives a different error in LibreOffice and remains rejected as invalid numeric syntax. These are documented differences, not fresh Excel runtime proof.

Source: https://support.microsoft.com/en-us/excel/functions/numbervalue-function . Inputs, secondary output, conflict notes and tests are retained in `oracles/numbervalue_explicit_separators_results.json` and the source/output workbooks.

Current local suite: 74 tests pass in 16.85 seconds with one original pivotCache warning. Fresh MKU and Test05 output categories remain unchanged. Full current TOPPLATE value/dependency reset is complete for all 34,612 anchors: 33,816 exact + 310 matching errors + 486 absent caches, zero other mismatches, unsupported outputs or observed cycles. Dependency inventory and implementation hashes are updated. The original model/AST was retained and uses identical declared default separators; this is not a fresh disk-load benchmark or evidence of source locale. Financial policies, client acceptance and runtime binding remain open.

### Operator-prefixed wildcard criteria, 04:53 IST

COUNTIF(S), SUMIF(S) and AVERAGEIFS now route `=pattern` and `<>pattern` through the same case-insensitive, newline-safe wildcard/tilde-escape matcher instead of treating wildcard characters literally. Explicit complements correctly include nonmatching blank tails over known reference geometry. The fixture covers literal escaped asterisk, empty strings, numbers, logicals, physical blanks, growth into a previously empty tail and both count/sum results. Relational wildcard criteria, criteria text over 255 characters, and error-valued inputs encountered by prefixed wildcard matching are explicitly unsupported with diagnostic notes, not silently excluded. This does not certify all criteria coercion or locales.

The secondary LibreOffice fixture agrees on the selected nontrivial pattern/escape/complement cases but disagrees for `=*` and `<>*`: it treats numeric/logical values as wildcard text. Microsoft describes `*` as matching text, so the prototype follows text-only positive matching, retaining the disagreement in `oracles/prefixed_wildcard_criteria_results.json`. Expected count/sum for the mixed fixture is 6/24 and 3/21, not LibreOffice's 8/37 and 1/8. No fresh Microsoft Excel runtime proof is claimed.

Source: https://support.microsoft.com/en-us/excel/get-started/use-the-countif-function-in-microsoft-excel ; https://exceljet.net/formulas/count-cells-that-do-not-contain .

Current local suite: 75 tests pass in 16.13 seconds, one original pivotCache warning. Fresh MKU remains 5,504 exact + 12 matching errors + 16 absent caches / 5,532. Test05 remains 27,692 no-cache anchors, zero errors, not value parity. Full current TOPPLATE replay after clearing all calculated values and dependency caches completes 34,612 anchors: 33,816 exact + 310 matching errors + 486 absent caches, zero other mismatches, unsupported outputs or observed cycles. Original workbook model and AST retained; this is not a disk-load cold-start benchmark. `topplate_prefixed_wildcard_results.json` and regenerated dependency inventory retain the evidence. Six optional private fixture tests skip without source files. Client closure, runtime binding, financial rules and full-corpus dependencies remain open.

### Source requirements, currency and A Class reconciliation, 04:57 IST

A live reread of the master Sheet establishes that the evidence already contains a reported requirement to **apply customer-provided exchange rates** (CAM-106, checklist message ID `19b6dba02bef804f`). CAM-087 separately leaves USD/EURO selection to finalise based on buy value. CAM-261 asks for Summary two decimals. The conflict tab reports an earlier display 2-to-6/backend-6 statement. These are source-register statements, not independently recovered original emails or blanket approval of one current financial policy. Exact subject/phrase searches in all three currently connected Gmail accounts returned zero, and direct reading of that ID in the work account returned no email. The register's original archive was harish.t, a different mailbox. Nothing here proves the original requirement absent. `financial_requirements_reconciliation.json` retains the distinction and a short list of remaining source needs, not a new question wall.

Additional authenticated source reads at pinned SRIM commit `540918090b1b2c64efcb6472caffefacc17da6ff` locate `currency.py`, its tests, and `reports/aclass_parts.py`. Earlier unlocated-A-Class status is superseded for this pinned Python file, not for every historical generator. Source hashes are in `generator_source/manifest.json`. Returned repository URLs are source-search references; separate reader/browser access and actual CAM 3.4 runtime binding remain unverified.

Currency uses units per USD and an admin-configured default quote currency. The module caches rates/settings until cleared. Reviewed admin DDL stores one current row per currency with created/updated timestamps; the reviewed create/update path has no effective-date or customer/project binding. No live DB values were accessed and no claim is made about every table elsewhere. More importantly, the Python conversion helper returns the original amount when either currency is unknown, while its SQL CASE builder returns NULL for unknown codes. The pinned source tests explicitly test passthrough. This is an implementation divergence to preserve and investigate, **not permission to adopt unknown-currency passthrough**. Actual customer rate values, their applicability and source quote currencies still need binding.

The A Class adapter selects one row per CPN and creates raw-price extended text before converting its unit cost. That alone would be a misleading final-export defect claim: the workbook builder overwrites quantity, price and extended columns with live CBOM formulas. Its quantities sum all eligible CPN rows; unit cost selects the first eligible row. A synthetic two-occurrence fixture (quantities 2 and 3, unit prices 2 and 3) yields total quantity 5, first cost 2, and extended 10, not a silently invented weighted-price total. An exclusion edit switches selection and quantity correctly; full stored price precision is retained. This demonstrates the historical mechanism, not the approved duplicate/occurrence/alternate-MPN policy. A comment saying a business rule was corrected is source commentary, not authenticated client approval.

The independent LibreOffice calculation disagrees on the boolean-to-text gate: `UPPER(TRUE&"")` is `1` there, whereas the prototype produces `TRUE`. Both select MATCH index 1 and return boolean TRUE from INDEX, but the text comparison is false in LibreOffice, giving unit/extended 0 there. This conflict is retained in `generator_currency_aclass_probe.json`, not hidden as parity. No fresh Microsoft Excel runtime proof is claimed. Initial local probe called a nonexistent API and was corrected; that failed attempt is recorded separately.

76 local tests pass in 16.13 seconds, one original pivotCache warning. Test 76 adds the emitted-source fixture and edit checks; no engine implementation file changed since the complete 75-test-code TOPPLATE replay. Thus the prior full replay remains implementation-equivalent, not a newly rerun 76-test benchmark. Six optional source-fixture tests skip when private source files are absent. Named routes remain 17, 265 not individually analysed, zero client accepted. CAM-106 is cross-referenced as an existing general requirement, not falsely counted as a newly validated client case.

Source register: https://docs.google.com/spreadsheets/d/152HAJt9dKJ-8h-5N3trMmnmCaJoYpb6y_6zYPePf5x4/edit?ouid=101517642553279522776&authuser=nagabhushana.raju.s%40digibull.ai

Returned private source references (reader access unverified):
- https://github.com/solutionsDigibull/BuLLMQuote_SRIM/blob/540918090b1b2c64efcb6472caffefacc17da6ff/mcp-tools/reporting/superset/currency.py
- https://github.com/solutionsDigibull/BuLLMQuote_SRIM/blob/540918090b1b2c64efcb6472caffefacc17da6ff/mcp-tools/reporting/superset/reports/aclass_parts.py
- https://github.com/solutionsDigibull/BuLLMQuote_SRIM/blob/540918090b1b2c64efcb6472caffefacc17da6ff/accomplish-ui/apps/daemon/src/browser-api-server.ts

### Numeric TEXT formatting, 05:08 IST

The old TEXT handler used Python fixed formatting, producing banker's/binary tie results such as TEXT(2.5,"0") -> "2", TEXT(1.125,"0.00") -> "1.12", and TEXT(2.675,"0.00") -> "2.67". The scoped numeric formatter now uses decimal half-up from the stored number's decimal representation, yielding "3", "1.13" and "2.68"; negative ties go away from zero. Decimal percent codes such as "0.0%" and leading-zero codes such as "0000000" are now supported. Dollar prefix sign placement is tested as "-$3" for -2.5. Negative values that round to zero suppress the negative sign in the tested secondary fixture. Source numeric values are unchanged; formatting returns text and is never a new backend financial rounding policy.

The supported grammar is optional literal dollar prefix, "0"/zero-padding placeholders or "#,##0", optional fixed zero decimals, and optional percent suffix. Output is deliberately dot-decimal/comma-group, not automatic locale inference. More complex sections, colors, dates, scientific/fraction codes, optional-digit formats such as "##0", and numeric format budgets (absolute input >=1e15, >15 decimals, >32 zero placeholders) explicitly reject with diagnostic notes. TEXT General retains its prior scalar stringify behavior and is not full General-format certification.

The retained LibreOffice fixture agrees on all 15 primary numeric/text outputs and the additional negative-dollar/zero-padding cases. Unsupported "##0" is recorded as a deliberate scope limit, not a claimed secondary match. Microsoft documents that TEXT rounds according to format, includes examples of fixed decimals, decimal percentages and zero padding, and recommends retaining original numeric cells. Microsoft rounding documentation states the half-up magnitude rule. This evidence plus secondary tests is not fresh Microsoft Excel runtime proof or broad binary-edge/locale certification.

Sources: https://support.microsoft.com/en-us/excel/functions/text-function ; https://support.microsoft.com/en-us/excel/round-a-number . Fixture/baseline conflicts/current results: `oracles/text_numeric_format_results.json`.

77 tests pass in 17.13 seconds, one original pivotCache warning. Fresh current MKU is unchanged (5,504 exact + 12 matching errors + 16 absent caches / 5,532), Test05 remains 27,692 no-cache outputs with zero errors, not parity. Full current TOPPLATE after all calculated-value/dependency caches reset is complete: 34,612 = 33,816 exact + 310 matching errors + 486 absent caches, zero other mismatches/unsupported outputs/observed cycles. Original model/AST retained; no disk-load cold-start claim. Current dependency inventory is regenerated from `topplate_text_local_checkpoint.pkl`. Engine source hashes and manifest are current. Financial rule/source binding/client acceptance gaps remain unchanged.

### Exact VLOOKUP/HLOOKUP selected reads, 05:12 IST

Review found that VLOOKUP/HLOOKUP eagerly evaluated the entire table, including unrelated return columns and the formula's own output cell. Exact direct-reference lookups now evaluate only the first key column/row and the selected return cell. This removes false cycles when the output is inside an unrelated table column/row, without suppressing a genuine cycle when that output is actually selected. Tests cover first duplicates, escaped wildcard lookup, missing keys, selected-cell edits, next-duplicate selection after a key edit, declared empty return columns/rows, explicit structured references and whole-column future growth. Approximate lookup and computed-table paths are unchanged and remain uncertified for broad semantics. Bare table names are still unsupported NameRef, not silently advertised as named-range support.

Declared reference geometry, not the occupied returned array width, now determines exact-path return-column bounds. An out-of-range return index yields #REF!; an index below1 yields #VALUE!. Selected physically empty return cells yield0. The separate LibreOffice fixture agrees on all selected-value/self-exclusion cases, except VLOOKUP with return column4 over a3-column range: LibreOffice produces #VALUE!, while Microsoft explicitly documents #REF! and the prototype follows Microsoft. No fresh Excel runtime proof or broad key/error/blank coercion certification is asserted.

TOPPLATE's parsed AST has 7,560 exact VLOOKUP calls: 6,120 direct RangeRef and1,440 explicit TableRef. This is a call count within that one workbook, not full raw-corpus semantic certification. Full current reevaluation after resetting every formula value/dependency completes34612anchors=33816exact+310matchingerrors+486absentcaches, zero othermismatches/unsupportedoutputs/observedcycles. The dependency inventory now has200032cell+61154rangeedges. More cell edges do not imply slower/faster or more/less correct by themselves; the graph records actual selected reads, remains conservative and only covers this snapshot. Original model/AST retained, not fresh disk-load performance proof.

80 tests pass in16.83seconds with one original pivotCache warning. Fresh current MKU5532 and Test0527692 output categories remain unchanged. Source hashes, `topplate_exact_lookup_results.json`, impact scan, oracle conflict evidence and dependency inventory are current. Financial/source policies,17named/265notindividuallyanalysed/0clientaccepted and wider stage3 scope remain unchanged.

Sources: https://support.microsoft.com/en-us/excel/functions/vlookup-function ; https://support.microsoft.com/en-us/excel/functions/hlookup-function .

### UNIQUE safety refusal, 05:14 IST

The previous UNIQUE routine flattened all input cells, ignored by_col/exactly_once arguments, and returned a Range that the workbook layer silently collapsed to one scalar. That is not a dynamic unique-list result. Until the engine has an explicit spill ownership/resize/obstruction/invalidation contract, UNIQUE now returns an unsupported diagnostic (`unique:dynamic-array-spill-contract`, #NAME?) in all contexts, including aggregate nesting. Registration remains for reporting, not support. This intentionally removes a plausible-but-wrong output; it does not claim an implemented UNIQUE feature.

Microsoft states that UNIQUE returns unique rows or columns, optional exactly-once behavior and a final array that spills. The raw typed census has23 containing cells (22 UNIQUE plus1 _XLFN.UNIQUE), represented by21 distinct source strings; those stay unsupported, not certified covered by the81-test count. Spills/names/structural edits remain acceptance gaps. Source: https://support.microsoft.com/en-us/excel/functions/unique-function .

81 tests pass in17.07seconds with one original pivotCache warning. Fresh MKU and Test05 categories are unchanged. Full current TOPPLATE value/dependency reset completes34612=33816exact+310matchingerrors+486absentcaches,0othermismatch/unsupportedoutputs/observedcycles. Model/AST retained, not diskcoldstart. No clientcase, production, financialpolicy or wholeenginecompletion upgrade.

### CAM205 array MATCH/ROW and partially dynamic lead-time reports, 05:20 IST

The live Source mails index lists the October5 candidate filename under CAM205 source message `1a10be03b858f0bd`. Drive candidate `12sTgQnuDBnH_Zjc0viNs52oC0LJ6K1me` matches that filename; original attachment bytes and complaint screenshots are still not hash-bound. Unlike the September16 static-count candidate, this file has20FG-wise and23consolidated report formulas, but its bucket labels and FG grand total are still literals.

A hypothetical edit of VL2!S26 for LM1000013 from4 to6 recounts the existing6-week bucket. FG counts4/6 go9/1 ->8/2; consolidated13/1 ->12/2; consolidated total remains45. A second hypothetical edit to10 produces no10-week bucket because that label does not exist. FG4/6become8/1 while literal FG grand totalB13stays33. Consolidated total drops45->44 because its formula sums only the existing fixed buckets. No report rows are generated by formula invalidation. These are mechanism probes, not the actual client edit or an approved bucket/deduplication policy. The formula bounds end at95, the last actual data row;96/97are blank spacers, so a suspected truncated-data-range explanation was checked and rejected.

The first probe exposed an engine defect that the earlier benchmarks did not: consolidated counts incorrectly computed65/64 instead of the separate LibreOffice45/44. MATCH scalarized its lookup array and ROW returned only the first row, breaking first-occurrence masks. This is now fixed by carrying explicit function array context. Exact MATCH maps lookup-array elements to first match positions, ROW/COLUMN return reference index arrays only when requested in array context, and computed INDEX targets preserve arrays. Scalar ROW/COLUMN behavior remains first row/column. Approximate MATCH array mode and ROW arrays over200000rows explicitly reject. This is not dynamic-spill implementation, broad coercion certification or a financial rule change.

All14recorded edited-cell values now agree with LibreOffice, including FG literals and consolidated totals. The synthetic first-occurrence SUMPRODUCT fixture also agrees. Ordinary legacy XLSX INDEX/SUM over MATCH arrays initially differed because LibreOffice scalarized them; repeating with explicit ArrayFormula CSE metadata agrees on all7synthetic outputs. The initial mismatch and corrected fixture are retained, not presented as one unqualified parity result. No fresh Microsoft Excel runtime proof or automatic CSE/version selection is claimed.

84local tests pass in17.28seconds with one original pivotCache warning. Seven private original/candidate fixture tests skip without their exact sources. The full83-test-code TOPPLATE replay is implementation-equivalent to84because the84th test only adds this candidate regression:34612=33816exact+310matchingerrors+486absentcaches,0othermismatches/unsupportedoutputs/observedcyclesaftercompletevalue/dependencyreset. Fresh current MKU/Test05categories unchanged. Model/AST retained, not diskcoldstart.17named/265notindividuallyanalysed/0clientaccepted remain unchanged; CAM205wasalready a named route.

Evidence: `cam205_bucket_label_static_total_probe.py/json`, source/output hypothetical copies, `oracles/match_row_array_context_results.json`, exact source hash and typed cell/formula evidence. No original source file or report definition was repaired.

Sources: https://support.microsoft.com/en-us/excel/functions/match-function ; https://support.microsoft.com/en-us/excel/functions/row-function ; https://support.microsoft.com/en-us/excel/functions/column-function .

Candidate: https://docs.google.com/spreadsheets/d/12sTgQnuDBnH_Zjc0viNs52oC0LJ6K1me/edit?usp=drivesdk&ouid=101517642553279522776&rtpof=true&sd=true&authuser=nagabhushana.raju.s%40digibull.ai
